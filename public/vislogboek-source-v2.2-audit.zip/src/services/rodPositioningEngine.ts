import {
  WeatherHourlyForecast,
  FishingLocation,
  FishingSession,
  FishSpecies,
  TimeSlot,
  ThermalTrend,
  WaterThermalAnalysis,
  CompassDirection,
  COMPASS_DIRECTIONS,
  RodPositioningAdvice,
} from '../types';
import { TIME_SLOT_HOURS } from './prognosisEngine';

export interface RodPositioningOptions {
  location?: FishingLocation;
  userWaterTemp?: number | null;
  thermalAnalysis: WaterThermalAnalysis;
  historicalSessions: FishingSession[];
  targetSlot?: TimeSlot;
}

/**
 * Bepaalt het meteorologisch seizoen voor de gegeven datum.
 */
function getSeasonNL(month: number): 'Voorjaar' | 'Zomer' | 'Herfst' | 'Winter' {
  if (month === 12 || month === 1 || month === 2) return 'Winter';
  if (month >= 3 && month <= 5) return 'Voorjaar';
  if (month >= 6 && month <= 8) return 'Zomer';
  return 'Herfst';
}

/**
 * Bepaalt soortspecifieke tactische zoekhypothesen voor hengelpositionering en visgedrag.
 * Waarschuwing: dit zijn biologisch onderbouwde zoekhypothesen, geen vangstgaranties.
 */
function determineTacticalHypothesis(
  species: FishSpecies | 'Algemeen',
  context: {
    isFlowingWater: boolean;
    waterType: string;
    waterDepth?: number;
    season: 'Voorjaar' | 'Zomer' | 'Herfst' | 'Winter';
    effectiveWaterTemp: number;
    avgAirTemp: number;
    avgWindSpeed: number;
    maxWindSpeed: number;
    windDirText: string;
    isColdWind: boolean;
    isStrongWind: boolean;
    isCalmWind: boolean;
    isWarmConditions: boolean;
    isWarmingPeriod: boolean;
    targetSlot?: TimeSlot;
    thermalTrend: ThermalTrend;
  }
): {
  recommendedZone: string;
  rationale: string;
  alternativeOption: string;
  confidenceLevel: 'Laag' | 'Matig' | 'Redelijk';
} {
  const {
    isFlowingWater,
    waterType,
    waterDepth,
    season,
    effectiveWaterTemp,
    avgAirTemp,
    avgWindSpeed,
    maxWindSpeed,
    windDirText,
    isColdWind,
    isCalmWind,
    isWarmConditions,
    isWarmingPeriod,
    targetSlot,
    thermalTrend,
  } = context;

  // SOORT: ROOFBLEI (Pelagische oppervlaktejager, stromingsminnend)
  if (species === 'Roofblei') {
    if (isFlowingWater) {
      return {
        recommendedZone: 'Stroomnaden, kribkoppen en turbulente oppervlaktezones',
        rationale: `Roofblei is een uitgesproken pelagische zichtjager die jaagt in de bovenste waterlaag rond stroomversnellingen, kribkoppen en stuwen. De wind (${windDirText} ${avgWindSpeed} km/u) versterkt oppervlakteonrust, wat prooivis desoriënteert. (Zoekhypothese voor oppervlaktejacht).`,
        alternativeOption:
          'Luwere wervelzones direct achter de stroomnaad bij extreem hoge stroomsnelheid of harde wind.',
        confidenceLevel: 'Redelijk',
      };
    }
    return {
      recommendedZone: 'Bovenste waterlaag, open water en zones met actieve oppervlaktebeweging',
      rationale: `Op stilstaand water zoekt roofblei open waterzones en winderige oevers op waar winddrift of inlaten prooivis concentreren. Biedt het aas hoog in het water aan. (Zoekhypothese voor pelagische jacht).`,
      alternativeOption: 'Oeverzones met zichtbare scholen speldaas of gemaaluitlaten.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: SNOEK (Visuele hinderlaagjager)
  if (species === 'Snoek') {
    if (season === 'Winter' || effectiveWaterTemp < 7 || (effectiveWaterTemp < 9 && isColdWind)) {
      return {
        recommendedZone: 'Diepere taluds en overgangen nabij samengeschoolde prooivis',
        rationale: `In koud water (${effectiveWaterTemp.toFixed(1)} °C) trekken witvisscholen naar diepere kuilen; snoek volgt deze prooiconcentraties en jaagt vanuit diepere hinderlagen. Vermijdt energieverspilling in koude golfslag. (Zoekhypothese voor winterjacht).`,
        alternativeOption:
          'Ondiepe rietkragen op zonnige wintermiddagen waar prooivis kort opwarmt.',
        confidenceLevel: waterDepth ? 'Redelijk' : 'Matig',
      };
    }
    if (isFlowingWater) {
      return {
        recommendedZone: 'Stroomluwe kribvakken, insteekhavens en taludoverslagen',
        rationale: `Op stromend water jaagt snoek vanuit luwtes op prooivissen die door de stroomnaad worden meegevoerd, zonder zelf continu energie te verliezen in de hoofdstroom. (Zoekhypothese voor hinderlaagjacht).`,
        alternativeOption:
          'Diepe buitenbochtkuilen of basaltgaten bij verhoogde rivierafvoer.',
        confidenceLevel: 'Redelijk',
      };
    }
    return {
      recommendedZone: 'Hinderlaagstructuren: vegetatieranden, rietkragen en taludovergangen',
      rationale: `Snoek jaagt vanuit dekking (waterplanten, rietkragen, taluds). Een matige kabbel (${windDirText} ${avgWindSpeed} km/u) en gedempt licht breken de lichtinval aan het wateroppervlak, wat de camouflage van de snoek ten opzichte van prooivis sterk verbetert. (Zoekhypothese voor hinderlaagjacht).`,
      alternativeOption:
        'Open water taluds of diepere geulen wanneer oevervegetatie ontbreekt.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: SNOEKBAARS (Lichtschuwe diepwaterrover met tapetum lucidum)
  if (species === 'Snoekbaars') {
    const isDarkSlot = targetSlot === 'Nacht' || targetSlot === 'Avond';
    if (isFlowingWater) {
      return {
        recommendedZone: 'Vaargeultaluds, stroomranden en harde bodemstructuren',
        rationale: `Snoekbaars prefereert harde zand- of grindbodems langs vaargeulen en kribkoppen. De vis jaagt op de scheidingslijn tussen harde stroming en bodemluwte. (Zoekhypothese voor dieptestructuur).`,
        alternativeOption:
          'Diepere insteekhavens of stroomafwaartse kuilen bij troebel water of hoog peil.',
        confidenceLevel: 'Redelijk',
      };
    }
    if (isDarkSlot) {
      return {
        recommendedZone: 'Ondiepere taludranden en overgangen (schemering/nachtjacht)',
        rationale: `Tijdens donkere uren trekt snoekbaars vanuit diepe kuilen naar ondiepere taluds en oeverzones om te jagen op prooivis die in het donker in het nadeel is. (Zoekhypothese voor nachtjacht).`,
        alternativeOption:
          'Overgangszone naar dieper water wanneer de maan fel schijnt of het water kristalhelder is.',
        confidenceLevel: 'Matig',
      };
    }
    return {
      recommendedZone: 'Diepere taluds, vaargeulen en schaduwrijke overgangszones',
      rationale: `Door het lichtversterkende tapetum lucidum mijdt snoekbaars overdag fel zonlicht op ondieptes. De vis zoekt overdag diepere kuilen, steile taluds of schaduwrijke plekken op. (Zoekhypothese voor lichtschuwheid).`,
      alternativeOption:
        'Brugschaduwen of diepere steilwanden indien het water zeer helder is.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: BAARS (Scholen- en zichtjager rond harde substraten)
  if (species === 'Baars') {
    return {
      recommendedZone: 'Harde bodemstructuren, taluds en schuilplaatsen bij kleinbroed',
      rationale: `Baars jaagt in scholen rond harde substraten (basalt, steigers, mosselbanken, takken). Wisselend licht en lichte kabbel (${avgWindSpeed} km/u) stimuleren scholenjacht op geconcentreerd kleinbroed. (Zoekhypothese voor structuurjacht).`,
      alternativeOption:
        'Diepere kuilen en zandafgravingen bij aanhoudende koude of felle windstilte.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: ZEELT (Warmteminnende planten- en modderbewoner)
  if (species === 'Zeelt') {
    if (season === 'Winter' || effectiveWaterTemp < 11) {
      return {
        recommendedZone: 'Diepere beschutte slibzones (extreme winterrust)',
        rationale: `Onder ~11–12 °C schakelt zeelt over op een diepe inactieve spaarstand in zachte bodemlagen. Ruwe golfslag en stroming worden strikt gemeden. (Zoekhypothese voor winterpassiviteit).`,
        alternativeOption:
          'Diepe, luwe havenbekkens of modderkuilen met minimale waterbeweging.',
        confidenceLevel: 'Matig',
      };
    }
    return {
      recommendedZone: 'Beschutte oeverzones met begroeiing, waterplanten of zachte modderbodem',
      rationale: `Zeelt foerageert tussen waterplanten (lelievelden, rietkragen) en in zachte modderbodems op slakjes en muggenlarven. Open, woelige oeverzones met zware aanlandige golfslag worden gemeden ten gunste van beschutte, slibrijke hoeken. (Zoekhypothese voor beschutte bodemfoerage).`,
      alternativeOption:
        'De overgangsrand direct voor de begroeiing naar iets dieper water bij kabbelend water.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: MEERVAL (Grote warmteminnende nacht- en bodemrover)
  if (species === 'Meerval') {
    if (effectiveWaterTemp < 12 || season === 'Winter') {
      return {
        recommendedZone: 'Diepste, stromingsvrije overwinteringskuilen (rusttoestand)',
        rationale: `Meerval is sterk warmteminnend. Onder 12–14 °C vertraagt de stofwisseling drastisch en zoekt de vis diepe, rustige bodemholen op zonder actief te jagen. (Zoekhypothese voor koude rust).`,
        alternativeOption: 'Diepe gaten in stilstaande zijarmen of havenmondingen.',
        confidenceLevel: 'Matig',
      };
    }
    return {
      recommendedZone: 'Diepe bodemkuilen overdag; stroomranden en ondiepere platen \'s nachts',
      rationale: `Meerval rust overdag bij diepe obstakels (omgewaaide bomen, diepe kribvakken) en trekt tijdens warme nachten of broeierig weer actief naar ondiepere stroomnaden en taluds om te jagen. (Zoekhypothese voor nachtelijke roof).`,
      alternativeOption:
        'Diepe uitspoelingsgaten achter kribben of stuwen.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: VOORN (Schoolvis in midden- en onderlaag)
  if (species === 'Voorn') {
    if (season === 'Winter' || effectiveWaterTemp < 7) {
      return {
        recommendedZone: 'Diepere rusthavens en kuilen; zonnige middagen op ondieptes',
        rationale: `In de winter verzamelt voorn zich in dichte scholen in diepe, rustige havens of vaargeulen; bij een zonnige namiddag trekken ze kort naar ondiepere luwe oeverzones. (Zoekhypothese voor winterscholing).`,
        alternativeOption: 'Luwte achter rietkragen of steigers.',
        confidenceLevel: 'Matig',
      };
    }
    return {
      recommendedZone: 'Overgangszones tussen oeverkabbel en rustig water (midden- en onderlaag)',
      rationale: `Voorn benut matige kabbel voor zuurstofrijk water en aangedreven zooplankton, maar zoekt dekking tegen predatoren langs de rand van waterplanten of taluds. (Zoekhypothese voor scholenfoerage).`,
      alternativeOption: 'Bovenste waterlaag bij warm, zwoel weer in de avond.',
      confidenceLevel: 'Matig',
    };
  }

  // SOORT: KARPER & BRASEM (Bodemazers, taluds, windgedreven voedsel) en OVERIG
  if (isFlowingWater) {
    return {
      recommendedZone: 'Stroomnaden, taluds en diepere overgangszones',
      rationale: `Op stromend water (${waterType.toLowerCase()}) dicteren stroming, vaargeulen en bodemverloop de vispositie veel sterker dan de oppervlakte-winddrift. De wind (${windDirText} ${avgWindSpeed} km/u) beïnvloedt vooral de oppervlaktelaag en lijnbeheersing; nabij de bodem blijft de hoofdstroming bepalend. (Zoekhypothese voor stromend water).`,
      alternativeOption:
        'Zoek bij harde wind of hoge afvoer de luwte van kribvakken, insteekhavens of de rustige binnenbocht.',
      confidenceLevel: 'Redelijk',
    };
  }

  if (season === 'Winter' || effectiveWaterTemp < 7 || (effectiveWaterTemp < 9 && isColdWind)) {
    return {
      recommendedZone: 'Diepere rustzone of luwe oever (beschut tegen koude wind)',
      rationale: `In koud water (${effectiveWaterTemp.toFixed(1)} °C) en bij koude wind (${windDirText} ${avgWindSpeed} km/u) koelt de aanlandige oever snel verder af. Vis vermijdt hier onnodig energieverlies in de golfslag en zoekt vaak stabielere diepere kuilen of de beschutte luwe oever op. (De grens van ~7–8 °C is een praktische vuistregel, geen star biologisch omslagpunt). (Zoekhypothese voor koude rust).`,
      alternativeOption:
        'Onderzoek op zonnige wintermiddagen met weinig wind een ondiepere zandplaat die door zonnestraling licht kan opwarmen.',
      confidenceLevel: waterDepth ? 'Redelijk' : 'Matig',
    };
  }

  if (season === 'Voorjaar' && (isWarmingPeriod || avgAirTemp >= 14)) {
    return {
      recommendedZone: 'Ondiepe, zonovergoten oeverzone of beschutte baai uit de wind',
      rationale: `In het voorjaar warmen ondieptes en uit de wind liggende baaien het snelst op onder invloed van zon. Karper en witvis trekken naar deze opwarmende zones om voedsel te zoeken in ontwakend bodemleven. (Zoekhypothese voor voorjaarsopwarming).`,
      alternativeOption:
        'Onderzoek de aanlandige zone alleen wanneer sprake is van een aanhoudend zachte, warme wind (bijv. zuiderwind) die warm water stuwt zonder koud diep water op te wellen.',
      confidenceLevel: 'Redelijk',
    };
  }

  if ((season === 'Zomer' || season === 'Herfst') && avgWindSpeed >= 12 && !isColdWind) {
    return {
      recommendedZone: 'Aanlandige oeverzone (windkant) als mogelijke zoekzone',
      rationale: `Een aanhoudende bries (${windDirText} ${avgWindSpeed} km/u${maxWindSpeed > avgWindSpeed ? `, stoten tot ~${maxWindSpeed} km/u` : ''}) stuwt warm oppervlaktewater, fytoplankton en zwevend voedsel richting de oever. Dit veroorzaakt lichte troebeling en zuurstofinbreng, wat foerageergedrag kan triggeren. Belangrijke nuance: aan de oppervlakte waait het water aanlandig, maar nabij de bodem ontstaat in dieper water vaak een compenserende retourstroom in tegengestelde richting. Behandel de windkant daarom als kansrijke zoekzone, niet als vaststaande garantie. (Zoekhypothese voor aanlandige wind).`,
      alternativeOption:
        'Luwe oeverzone direct achter een rietkraag of een dieper talud, zeker als hevige golfslag het bodemaas verplaatst of vuil de hoofdlijn belaagt.',
      confidenceLevel: 'Matig',
    };
  }

  if (season === 'Zomer' && isCalmWind && isWarmConditions) {
    return {
      recommendedZone: 'Zuurstofrijke overgangszones, dieper water of schaduwrijke overkappingen',
      rationale: `Bij weinig wind (${avgWindSpeed} km/u) en warme omstandigheden (~${avgAirTemp.toFixed(1)} °C) kan in stilstaand ondiep water zuurstofafname optreden. Vis zoekt vaak beschutting in diepere kuilen, bij waterplantenvelden of onder overhangende bomen. Let op: weinig wind betekent niet automatisch stilstaand water; thermische circulatie kan nabij de bodem nog steeds voor lichte waterverplaatsing zorgen. (Zoekhypothese voor warme luwte).`,
      alternativeOption:
        'Vroeg in de ochtend of laat in de avond foerageert vis vaak kort op de ondieptes wanneer het oppervlak iets afkoelt.',
      confidenceLevel: 'Matig',
    };
  }

  // Algemene / stabiele condities
  return {
    recommendedZone: 'Aanlandige zone of diepere taluds',
    rationale: `Bij een matige wind (${windDirText} ${avgWindSpeed} km/u) en een ${thermalTrend.toLowerCase()} zijn de omstandigheden evenwichtig. Vis kan zowel langs overgangszones aan de windkant foerageren als rusten bij diepere taluds. Voorkom vastpinnen op één enkele zone. (Zoekhypothese voor overgangsperiode).`,
    alternativeOption:
      'De luwe zijde van een eiland, rietkraag of brugpeiler waar natuurlijk voedsel neerslaat.',
    confidenceLevel: 'Matig',
  };
}

/**
 * Analyseert tactische hengelpositionering en visbeweging op basis van fysische factoren
 * (wind, temperatuur, thermische trend, diepte en seizoen) en optionele persoonlijke logboekdata.
 *
 * BELANGRIJK: Deze engine is 100% onafhankelijk van de biologische activiteitsindex (1.0-10.0)
 * en de Poisson-vangstkansformule. Er worden géén bonuspunten of kansverhogingen berekend.
 */
export function analyzeRodPositioning(
  dateStr: string,
  forecasts: WeatherHourlyForecast[],
  species: FishSpecies | 'Algemeen',
  options: RodPositioningOptions
): RodPositioningAdvice {
  const { location, userWaterTemp, thermalAnalysis, historicalSessions, targetSlot } = options;

  // 1. Relevante weersperiode selecteren (targetSlot of daggemiddelde)
  const dayForecasts = forecasts.filter((h) => h.time.startsWith(dateStr));

  let slotForecasts = dayForecasts;
  if (targetSlot && TIME_SLOT_HOURS[targetSlot]) {
    const config = TIME_SLOT_HOURS[targetSlot];
    const filtered = dayForecasts.filter((h) => {
      const hour = parseInt(h.time.slice(11, 13), 10);
      return hour >= config.start && hour < config.end;
    });
    if (filtered.length > 0) {
      slotForecasts = filtered;
    }
  }

  // Bereken representatieve wind- en temperatuurwaarden
  const sampleForecasts = slotForecasts.length > 0 ? slotForecasts : dayForecasts;

  let avgWindSpeed = 12;
  let maxWindSpeed = 15;
  let windDirText = 'Onbekend';
  let avgAirTemp = 14;
  let windTrend: 'Aantrekkend' | 'Afnemend' | 'Draaiend' | 'Stabiel' = 'Stabiel';
  let intraSessionNote: string | undefined = undefined;

  if (sampleForecasts.length > 0) {
    const totalSpeed = sampleForecasts.reduce((sum, h) => sum + (h.windSpeed || 0), 0);
    avgWindSpeed = Math.round((totalSpeed / sampleForecasts.length) * 10) / 10;
    maxWindSpeed = Math.round(Math.max(...sampleForecasts.map((h) => h.windSpeed || 0)));

    const totalTemp = sampleForecasts.reduce((sum, h) => sum + (h.temperature || 0), 0);
    avgAirTemp = Math.round((totalTemp / sampleForecasts.length) * 10) / 10;

    // Modale windrichtingstekst
    const dirCounts: Record<string, number> = {};
    for (const h of sampleForecasts) {
      const dt = h.windDirectionText || 'ZW';
      dirCounts[dt] = (dirCounts[dt] || 0) + 1;
    }
    let topCount = -1;
    for (const [dir, cnt] of Object.entries(dirCounts)) {
      if (cnt > topCount) {
        topCount = cnt;
        windDirText = dir;
      }
    }

    // Analyse van weersverloop binnen het tijdvak (verandering van windkracht en richting)
    const firstH = sampleForecasts[0];
    const lastH = sampleForecasts[sampleForecasts.length - 1];
    const speedStart = firstH?.windSpeed ?? avgWindSpeed;
    const speedEnd = lastH?.windSpeed ?? avgWindSpeed;
    const dirStart = firstH?.windDirectionText || windDirText;
    const dirEnd = lastH?.windDirectionText || windDirText;
    const speedDelta = speedEnd - speedStart;

    if (dirStart !== dirEnd && sampleForecasts.length > 1) {
      windTrend = 'Draaiend';
      intraSessionNote = `Wind draait van ${dirStart} naar ${dirEnd}; oppervlaktewaterbeweging kan tijdens het tijdvak geleidelijk verschuiven.`;
    } else if (speedDelta >= 6) {
      windTrend = 'Aantrekkend';
      intraSessionNote = `Wind trekt aan van ${speedStart} naar ${speedEnd} km/u (stoten tot ~${maxWindSpeed} km/u); watermenging en golfslag nemen toe.`;
    } else if (speedDelta <= -6) {
      windTrend = 'Afnemend';
      intraSessionNote = `Wind neemt af van ${speedStart} naar ${speedEnd} km/u; oppervlaktedrift zwakt geleidelijk af.`;
    } else {
      windTrend = 'Stabiel';
    }
  }

  // 2. Seizoen & thermische context (inclusief 24-72u historie en modelschatting)
  const targetDate = new Date(dateStr);
  const month = targetDate.getMonth() + 1; // 1-12
  const season = getSeasonNL(month);

  const hasMeasuredTemp = typeof userWaterTemp === 'number' && !isNaN(userWaterTemp);
  const effectiveWaterTemp = hasMeasuredTemp
    ? userWaterTemp
    : thermalAnalysis.estimatedWaterTemp ?? avgAirTemp;

  // Biologisch genuanceerde vlaggen (behandeld als vuistregels/heuristieken, niet als harde breekpunten)
  const isCoolingPeriod = thermalAnalysis.trend === 'Waarschijnlijke afkoeling';
  const isWarmingPeriod = thermalAnalysis.trend === 'Waarschijnlijke opwarming';
  const isColdWind = avgAirTemp < 8 || (avgAirTemp < 12 && season === 'Voorjaar') || isCoolingPeriod;
  const isStrongWind = avgWindSpeed >= 20 || maxWindSpeed >= 35;
  const isCalmWind = avgWindSpeed <= 10;
  const isWarmConditions = effectiveWaterTemp >= 21 || avgAirTemp >= 23;

  // 3. Watertype & diepte-eigenschappen
  const waterType = location?.waterType || 'Plas/Zandafgraving';
  const isFlowingWater = waterType === 'Rivier' || waterType === 'Kanaal';
  const waterDepth = location?.waterDepth;

  // 4. Bepaling van soortspecifieke tactische zoekhypothese
  const tacticalHypothesis = determineTacticalHypothesis(species, {
    isFlowingWater,
    waterType,
    waterDepth,
    season,
    effectiveWaterTemp,
    avgAirTemp,
    avgWindSpeed,
    maxWindSpeed,
    windDirText,
    isColdWind,
    isStrongWind,
    isCalmWind,
    isWarmConditions,
    isWarmingPeriod,
    targetSlot,
    thermalTrend: thermalAnalysis.trend,
  });

  // 5. Expliciete ontbrekende informatie (eerlijke modelbeperkingen, beknopt en zonder dubbele teksten)
  const missingInformation: string[] = [
    'Exacte oeverlijnoriëntatie en omtrek van het water zijn niet bekend in het systeem (GPS is een enkel punt). Onderzoek ter plekke welke oever daadwerkelijk de wind opvangt (aanlandig) of beschut ligt (aflandig).',
  ];

  if (!waterDepth) {
    missingInformation.push(
      'Waterdiepte en bodemprofiel zijn niet specifiek gedocumenteerd; standaard aanname van 2,0 m gehanteerd. Pas dieptetactiek ter plekke aan.'
    );
  } else {
    missingInformation.push(
      `Geregistreerde gemiddelde diepte is ${waterDepth} m; lokale geulen, taluds of plateaus kunnen afwijken.`
    );
  }

  if (!hasMeasuredTemp) {
    missingInformation.push(
      `Watertemperatuur is een modelschatting (~${effectiveWaterTemp.toFixed(1)} °C), geen directe thermometermeting op de stek.`
    );
  }

  missingInformation.push(
    'Lokale microklimaten (bomenrijen, rietkragen, bebouwing) kunnen de windrichting aan het wateroppervlak sterk afbuigen.'
  );

  // 6. Persoonlijke leerresultaten (Strikte drempel: >= 11 voltooide sessies op DEZELFDE stek, waarvan >= 6 met baitDirection)
  let personalEvidence: RodPositioningAdvice['personalEvidence'] = undefined;

  if (location?.id) {
    // Filter uitsluitend voltooide sessies op exact deze geregistreerde stek (benchmark uitgesloten)
    const validSpotSessions = historicalSessions.filter(
      (s) =>
        s.locationId === location.id &&
        (s.outcome === 'catch' || s.outcome === 'skunk_confirmed') &&
        !s.isBenchmark
    );

    const totalCompleted = validSpotSessions.length;

    // Filter sessies met een bruikbare baitDirection
    const withDirection = validSpotSessions.filter(
      (s) => s.baitDirection && COMPASS_DIRECTIONS.includes(s.baitDirection)
    );

    const hasSufficientData = totalCompleted >= 11 && withDirection.length >= 6;

    let summaryNote = '';
    let favoriteDirection: CompassDirection | null = null;

    if (!hasSufficientData) {
      if (totalCompleted < 11) {
        summaryNote = `Er zijn ${totalCompleted} van de minimaal 11 voltooide sessies op deze specifieke stek geregistreerd. De richtingshistorie is nog niet toereikend voor persoonlijke nuances (puur algemeen fysisch advies).`;
      } else {
        summaryNote = `Er zijn ${totalCompleted} voltooide sessies op deze stek, maar slechts ${withDirection.length} met een geregistreerde aasaanbiedingsrichting (minimaal 6 vereist). Vul de werprichting in bij komende sessies om dit persoonlijke profiel op te bouwen.`;
      }
    } else {
      // Analyseer richtingensucces
      const dirStats: Record<CompassDirection, { total: number; catches: number }> = {} as any;
      for (const dir of COMPASS_DIRECTIONS) {
        dirStats[dir] = { total: 0, catches: 0 };
      }

      for (const s of withDirection) {
        const d = s.baitDirection!;
        if (dirStats[d]) {
          dirStats[d].total++;
          if (s.outcome === 'catch') {
            dirStats[d].catches++;
          }
        }
      }

      // Zoek de meest succesvolle richting met minimaal 2 sessies
      let bestDir: CompassDirection | null = null;
      let bestRate = -1;
      let bestCatches = 0;

      for (const dir of COMPASS_DIRECTIONS) {
        const st = dirStats[dir];
        if (st.total >= 2) {
          const rate = st.catches / st.total;
          if (rate > bestRate || (rate === bestRate && st.catches > bestCatches)) {
            bestRate = rate;
            bestCatches = st.catches;
            bestDir = dir;
          }
        }
      }

      favoriteDirection = bestDir;

      if (bestDir && bestRate > 0) {
        const stat = dirStats[bestDir];
        const pct = Math.round(bestRate * 100);
        summaryNote = `Voorzichtige empirische logboekobservatie (N=${totalCompleted} voltooide sessies, waarvan ${withDirection.length} met geregistreerde richting): Aasaanbieding richting ${bestDir} leverde in ${stat.catches} van de ${stat.total} sessies vangst op (${pct}%). Dit is een voorlopige waarneming op basis van eigen data, geen wetenschappelijk bewijs. Laat dit het algemene fysische advies hooguit licht nuanceren.`;
      } else {
        summaryNote = `Op basis van ${totalCompleted} voltooide sessies (${withDirection.length} met geregistreerde richting) tekent zich nog geen duidelijke voorkeursrichting af op deze stek. Blijf het algemene wind- en diepteadvies volgen.`;
      }
    }

    personalEvidence = {
      hasSufficientData,
      totalCompletedSessionsOnSpot: totalCompleted,
      sessionsWithDirection: withDirection.length,
      summaryNote,
      favoriteDirection,
    };
  }

  return {
    recommendedZone: tacticalHypothesis.recommendedZone,
    rationale: tacticalHypothesis.rationale,
    alternativeOption: tacticalHypothesis.alternativeOption,
    confidenceLevel: tacticalHypothesis.confidenceLevel,
    windContext: {
      directionText: windDirText,
      speedKmH: avgWindSpeed,
      gustsKmH: maxWindSpeed > avgWindSpeed ? maxWindSpeed : undefined,
      isStrongWind,
      isColdWind,
      windTrend,
      intraSessionNote,
    },
    thermalContext: {
      trend: thermalAnalysis.trend,
      season,
      waterTempNote: hasMeasuredTemp
        ? `Gemeten: ${userWaterTemp} °C`
        : thermalAnalysis.estimatedWaterTemp !== null
        ? `Geschat: ~${thermalAnalysis.estimatedWaterTemp} °C`
        : 'Geen watertemperatuur bekend',
    },
    missingInformation,
    personalEvidence,
  };
}
