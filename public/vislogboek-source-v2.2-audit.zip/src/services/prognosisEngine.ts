import {
  FishSpecies,
  TimeSlot,
  DayPrognosis,
  TimeSlotAnalysis,
  FactorBreakdown,
  WeatherHourlyForecast,
  FishingSession,
  PresenceObservationType,
  PrognosisSnapshot,
  FishingLocation,
  WaterThermalAnalysis,
} from '../types';
import { SPECIES_PROFILES, SpeciesProfile, calculateThermalEfficiency } from './fishProfiles';
import { BENCHMARK_SESSION_ID, db } from '../db/db';
import { analyzeWaterThermalDevelopment } from './waterThermalEngine';
import { analyzeRodPositioning } from './rodPositioningEngine';

export const TIME_SLOT_HOURS: Record<TimeSlot, { start: number; end: number; rangeLabel: string }> = {
  Nacht: { start: 0, end: 6, rangeLabel: '00:00 – 06:00' },
  Ochtend: { start: 6, end: 12, rangeLabel: '06:00 – 12:00' },
  Middag: { start: 12, end: 18, rangeLabel: '12:00 – 18:00' },
  Avond: { start: 18, end: 24, rangeLabel: '18:00 – 24:00' },
};

function getSeason(month: number): 'winter' | 'lente' | 'zomer' | 'herfst' {
  if (month === 12 || month === 1 || month === 2) return 'winter';
  if (month >= 3 && month <= 5) return 'lente';
  if (month >= 6 && month <= 8) return 'zomer';
  return 'herfst';
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

/**
 * Berekent het Wilson score 95% betrouwbaarheidsinterval voor een binomiaal percentage.
 * Let op: berekent de steekproefonzekerheid van de binomiale fractie, maar corrigeert niet
 * voor variatie in sessieduur, vistechniek of stekclustering.
 */
export function calculateWilsonInterval(
  successes: number,
  total: number,
  confidenceZ = 1.96
): [number, number] {
  if (total <= 0) return [0, 0];
  const p = successes / total;
  const z = confidenceZ;
  const z2 = z * z;
  const denominator = 1 + z2 / total;
  const center = (p + z2 / (2 * total)) / denominator;
  const spread = (z * Math.sqrt((p * (1 - p)) / total + z2 / (4 * total * total))) / denominator;

  const lower = Math.max(0, Math.round((center - spread) * 100));
  const upper = Math.min(100, Math.round((center + spread) * 100));
  return [lower, upper];
}

/**
 * Berekent de luchtdrukverandering (Delta P) over de afgelopen 6–24 uur uit de uurlijkse reeks.
 */
export function findPressureTrend(
  targetTimeIso: string,
  allForecasts: WeatherHourlyForecast[]
): { deltaHpa: number | null; trendDescription: string; known: boolean } {
  const targetDateMs = new Date(targetTimeIso).getTime();
  if (isNaN(targetDateMs) || allForecasts.length === 0) {
    return { deltaHpa: null, trendDescription: 'Druktrend onbekend (onvoldoende uurdata)', known: false };
  }

  // Zoek uurmeting dichtst bij target
  const currentEntry = allForecasts.find(
    (h) => Math.abs(new Date(h.time).getTime() - targetDateMs) < 1800000
  );
  if (!currentEntry) {
    return { deltaHpa: null, trendDescription: 'Druktrend onbekend', known: false };
  }

  // Zoek meting van 12 uur (of tussen 6 en 18 uur) daarvóór
  const targetPastMs = targetDateMs - 12 * 3600000;
  let pastEntry: WeatherHourlyForecast | null = null;
  let minDiff = Infinity;

  for (const h of allForecasts) {
    const hMs = new Date(h.time).getTime();
    const diff = Math.abs(hMs - targetPastMs);
    if (diff < minDiff && diff <= 3 * 3600000) {
      minDiff = diff;
      pastEntry = h;
    }
  }

  if (!pastEntry) {
    return {
      deltaHpa: null,
      trendDescription: 'Druktrend onbekend (geen historische 12-uurs meting beschikbaar in dataset)',
      known: false,
    };
  }

  const delta = Math.round((currentEntry.pressure - pastEntry.pressure) * 10) / 10;

  if (delta > 2.5) {
    return { deltaHpa: delta, trendDescription: `Snel stijgende luchtdruk (+${delta} hPa in 12u)`, known: true };
  } else if (delta < -2.5) {
    return { deltaHpa: delta, trendDescription: `Dalende luchtdruk (${delta} hPa in 12u, naderend front)`, known: true };
  } else {
    return { deltaHpa: delta, trendDescription: `Stabiele barometer (${delta >= 0 ? '+' : ''}${delta} hPa in 12u)`, known: true };
  }
}

/**
 * Analyseert één specifiek tijdvak voor een vissoort op een gegeven datum
 */
function analyzeTimeSlot(
  slot: TimeSlot,
  forecastsInSlot: WeatherHourlyForecast[],
  allForecasts: WeatherHourlyForecast[],
  species: FishSpecies,
  profile: SpeciesProfile,
  date: Date,
  historicalSessions: FishingSession[],
  currentDateRef: Date,
  userWaterTemp?: number | null,
  presenceObs?: PresenceObservationType
): TimeSlotAnalysis {
  const hoursConfig = TIME_SLOT_HOURS[slot];
  const month = date.getMonth() + 1;
  const season = getSeason(month);

  // Controleer of dit tijdvak reeds volledig verstreken is
  const targetDateStr = date.toISOString().slice(0, 10);
  const curDateStr = currentDateRef.toISOString().slice(0, 10);
  const curHour = currentDateRef.getHours();

  let isPast = false;
  let remainingHours = hoursConfig.end - hoursConfig.start;

  if (targetDateStr < curDateStr) {
    isPast = true;
    remainingHours = 0;
  } else if (targetDateStr === curDateStr) {
    if (curHour >= hoursConfig.end) {
      isPast = true;
      remainingHours = 0;
    } else if (curHour >= hoursConfig.start) {
      // Actief tijdvak
      isPast = false;
      remainingHours = Math.max(1, hoursConfig.end - curHour);
    }
  }

  // Gemiddelde weerswaarden in dit tijdvak
  let avgAirTemp = 13;
  let avgPressure = 1015;
  let avgWindSpeed = 12;
  let dominantWindDir = 'ZW';
  let totalPrecip = 0;
  let avgCloud = 50;
  let representativeTimeIso = `${targetDateStr}T${String(hoursConfig.start + 3).padStart(2, '0')}:00`;

  if (forecastsInSlot.length > 0) {
    avgAirTemp = forecastsInSlot.reduce((s, h) => s + h.temperature, 0) / forecastsInSlot.length;
    avgPressure = forecastsInSlot.reduce((s, h) => s + h.pressure, 0) / forecastsInSlot.length;
    avgWindSpeed = forecastsInSlot.reduce((s, h) => s + h.windSpeed, 0) / forecastsInSlot.length;
    dominantWindDir = forecastsInSlot[0]?.windDirectionText || 'ZW';
    totalPrecip = forecastsInSlot.reduce((s, h) => s + h.precipitation, 0);
    avgCloud = forecastsInSlot.reduce((s, h) => s + h.cloudCover, 0) / forecastsInSlot.length;
    representativeTimeIso = forecastsInSlot[Math.floor(forecastsInSlot.length / 2)].time;
  }

  // 1. Temperatuurfactor & Fysiologische Efficiëntie E_temp
  // Onderscheid watertemperatuur vs. luchttemperatuur
  const isWaterTempMeasured = typeof userWaterTemp === 'number' && !isNaN(userWaterTemp);
  const effectiveTemp = isWaterTempMeasured ? (userWaterTemp as number) : avgAirTemp;

  const { efficiency: thermalEff, description: tempDesc, impact: tempImpact } =
    calculateThermalEfficiency(effectiveTemp, profile);

  let tempDetailText = tempDesc;
  if (!isWaterTempMeasured) {
    tempDetailText +=
      ' (Let op: gebaseerd op 2m-luchttemperatuur; werkelijke watertemperatuur kan door thermische inertie en stratificatie afwijken).';
  } else {
    tempDetailText += ' (Gebaseerd op geverifieerde gemeten watertemperatuur).';
  }

  const temperatureFactor: FactorBreakdown = {
    score: Math.round((thermalEff * 4 - 2) * 10) / 10,
    impact: tempImpact,
    title: 'Temperatuur & Metabolisme',
    detail: tempDetailText,
  };

  // 2. Luchtdrukfactor & Trend (12-uurs Delta P)
  const pressureTrend = findPressureTrend(representativeTimeIso, allForecasts);
  let pressureModulator = 1.0;
  let pressImpact: 'positief' | 'neutraal' | 'negatief' = 'neutraal';
  let pressDetail = '';

  const [pressOptMin, pressOptMax] = profile.optimalPressureRange;

  if (pressureTrend.known && pressureTrend.deltaHpa !== null) {
    if (pressureTrend.deltaHpa < -2.5) {
      if (profile.species === 'Snoek' || profile.species === 'Karper') {
        pressureModulator = 1.07;
        pressImpact = 'positief';
        pressDetail = `${pressureTrend.trendDescription}. Naderend front triggert vaak verhoogde foerageerdrang.`;
      } else {
        pressureModulator = 0.95;
        pressImpact = 'neutraal';
        pressDetail = `${pressureTrend.trendDescription}. Snelle drukdaling kan bodemvissen voorzichtiger maken.`;
      }
    } else if (pressureTrend.deltaHpa > 2.5) {
      pressureModulator = 0.94;
      pressImpact = 'negatief';
      pressDetail = `${pressureTrend.trendDescription}. Snelle drukstijging remt aasgedrag tijdelijk af.`;
    } else {
      pressureModulator = avgPressure >= pressOptMin && avgPressure <= pressOptMax ? 1.05 : 1.0;
      pressImpact = pressureModulator > 1.0 ? 'positief' : 'neutraal';
      pressDetail = `${pressureTrend.trendDescription} rond ${Math.round(avgPressure)} hPa; stabiele hydrostatische druk.`;
      if (profile.pressureSensitivity === 'hoog' && pressureModulator > 1.0) {
        pressDetail += ` Gunstig voor drukgevoelige soort (${species}).`;
      }
    }
  } else {
    pressureModulator = 1.0;
    pressImpact = 'neutraal';
    pressDetail = `Luchtdruk bedraagt ${Math.round(avgPressure)} hPa. ${pressureTrend.trendDescription}; geen kunstmatige aanname gemaakt.`;
  }

  if (avgPressure < 998) {
    pressureModulator *= 0.92;
    pressImpact = 'negatief';
    pressDetail += ' Diepe depressie gaat gepaard met instabiel weer.';
  } else if (avgPressure > 1028) {
    pressureModulator *= 0.95;
    pressDetail += ' Hoge barometerstand leidt vaak tot passievere vis in helder water.';
  }

  const pressureFactor: FactorBreakdown = {
    score: Math.round((pressureModulator - 1.0) * 10 * 10) / 10,
    impact: pressImpact,
    title: 'Luchtdruk & Trend',
    detail: pressDetail,
  };

  // 3. Windfactor (inclusief profielvoorkeur en storingsdrempel)
  let windModulator = 1.0;
  let windImpact: 'positief' | 'neutraal' | 'negatief' = 'neutraal';
  let windDetail = '';

  const isPreferredWind =
    profile.preferredWindDirections && profile.preferredWindDirections.includes(dominantWindDir);

  if (avgWindSpeed > profile.disruptiveWindThresholdKmH) {
    windModulator = 0.82;
    windImpact = 'negatief';
    windDetail = `Harde wind (${Math.round(avgWindSpeed)} km/u) verstoort beetregistratie en aasaanbieding aanzienlijk.`;
  } else if (avgWindSpeed >= 9 && avgWindSpeed <= 22) {
    windModulator = 1.06;
    windImpact = 'positief';
    windDetail = `Matige wind (${dominantWindDir}, ${Math.round(avgWindSpeed)} km/u) creëert gunstige oeverkabbel en zuurstoftoevoer.`;
  } else if (avgWindSpeed < 4) {
    windModulator = 0.96;
    windImpact = 'neutraal';
    windDetail = `Bladstil water (${Math.round(avgWindSpeed)} km/u); spiegelglad oppervlak verhoogt argwaan bij schuwe vis.`;
  } else {
    windModulator = 1.0;
    windImpact = 'neutraal';
    windDetail = `Wind (${dominantWindDir}, ${Math.round(avgWindSpeed)} km/u) heeft een neutrale invloed.`;
  }

  if (isPreferredWind && avgWindSpeed >= 6 && avgWindSpeed <= profile.disruptiveWindThresholdKmH) {
    windDetail += ` Windrichting (${dominantWindDir}) sluit aan bij de voorkeur van ${species}.`;
  }

  if ((dominantWindDir === 'O' || dominantWindDir === 'NO') && (season === 'herfst' || season === 'winter')) {
    windModulator *= 0.94;
    windDetail += ' Kille oostenwind kan ondiepe oeverzones afkoelen.';
  }

  const windFactor: FactorBreakdown = {
    score: Math.round((windModulator - 1.0) * 10 * 10) / 10,
    impact: windImpact,
    title: 'Wind & Oppervlakte',
    detail: windDetail,
  };

  // 4. Seizoensfactor (gedempt om dubbeltelling met temperatuur te voorkomen)
  const seasonRaw = profile.seasonalWeights[season];
  const seasonModulator = 0.92 + (seasonRaw / 10) * 0.16;
  const seasonImpact: 'positief' | 'neutraal' | 'negatief' =
    seasonRaw >= 8.5 ? 'positief' : seasonRaw <= 3.5 ? 'negatief' : 'neutraal';

  const seasonFactor: FactorBreakdown = {
    score: Math.round((seasonModulator - 1.0) * 10 * 10) / 10,
    impact: seasonImpact,
    title: 'Seizoensritme',
    detail: `Seizoen ${season} heeft een biologische achtergrondfactor van ${seasonRaw}/10 voor ${species}.`,
  };

  // 5. Tijdstip & Schemering
  let timeModulator = 1.0;
  let timeImpact: 'positief' | 'neutraal' | 'negatief' = 'neutraal';
  let timeDetail = '';

  const isPreferredSlot = profile.preferredSlots.includes(slot);
  if (isPreferredSlot) {
    timeModulator = 1.08;
    timeImpact = 'positief';
    timeDetail = `${slot} sluit aan bij het natuurlijke foerageerpatroon van ${species}.`;
  } else {
    timeModulator = 0.94;
    timeImpact = 'neutraal';
    timeDetail = `${slot} is gemiddeld genomen een rustiger dagdeel voor ${species}.`;
  }

  if (profile.crepuscularBonus && (slot === 'Ochtend' || slot === 'Avond')) {
    timeModulator = Math.min(1.15, timeModulator * 1.06);
    timeDetail += ' Schemering biedt natuurlijk lichtvoordeel.';
  }

  const timeOfDayFactor: FactorBreakdown = {
    score: Math.round((timeModulator - 1.0) * 10 * 10) / 10,
    impact: timeImpact,
    title: 'Tijdstip & Licht',
    detail: timeDetail,
  };

  // 6. Bewolking & Neerslag (geen dubbele telling van regen en bewolking)
  let precipModulator = 1.0;
  let precipImpact: 'positief' | 'neutraal' | 'negatief' = 'neutraal';
  let precipDetail = '';

  if (totalPrecip >= 7.0) {
    precipModulator = 0.92;
    precipImpact = 'negatief';
    precipDetail = `Langdurige zware neerslag (${totalPrecip.toFixed(1)} mm) kan water vertroebelen en beïnvloedt techniek.`;
  } else if (totalPrecip > 0.2 && totalPrecip < 4.0) {
    precipModulator = profile.rainPreference === 'licht_positief' ? 1.05 : 1.0;
    precipImpact = profile.rainPreference === 'licht_positief' ? 'positief' : 'neutraal';
    precipDetail = `Lichte regen (${totalPrecip.toFixed(1)} mm) breekt het wateroppervlak en stimuleert activiteit.`;
  } else if (avgCloud >= 70) {
    precipModulator = 1.03;
    precipImpact = 'positief';
    precipDetail = `Zwaarbewolkt (${Math.round(avgCloud)}%); diffuus licht vermindert argwaan.`;
    if (profile.cloudPreference === 'bewolkt') {
      precipDetail += ` Gedempt licht sluit gunstig aan bij ${species}.`;
    }
  } else if (avgCloud >= 30 && avgCloud < 70) {
    precipModulator = profile.cloudPreference === 'wisselend' ? 1.02 : 1.0;
    precipImpact = 'neutraal';
    precipDetail = `Wisselende bewolking (${Math.round(avgCloud)}%); dynamisch lichtbeeld${profile.cloudPreference === 'wisselend' ? ` past goed bij de zichtjacht van ${species}` : ''}.`;
  } else {
    precipModulator = 1.0;
    precipImpact = 'neutraal';
    precipDetail = 'Droge omstandigheden met helder zicht.';
  }

  const precipitationFactor: FactorBreakdown = {
    score: Math.round((precipModulator - 1.0) * 10 * 10) / 10,
    impact: precipImpact,
    title: 'Bewolking & Neerslag',
    detail: precipDetail,
  };

  // --- NON-LINEAIR BEGRENSD MODEL VOOR BIOLOGISCHE ACTIVITEITSINDEX ---
  // Temperatuur fungeert als snelheidsbepalende fysiologische factor (rate-limiting biological constraint).
  // Bij lage temperatuur is de stofwisseling fundamenteel geremd; gunstig weer kan dit niet onbeperkt compenseren.
  const envModulator =
    0.28 * pressureModulator +
    0.24 * windModulator +
    0.16 * seasonModulator +
    0.22 * timeModulator +
    0.10 * precipModulator;

  // Power scale on thermal efficiency: E_temp^0.85
  const metabolicCeiling = Math.pow(thermalEff, 0.85);
  const rawActivityScore = 1.0 + 9.0 * metabolicCeiling * envModulator;
  const activityScore = Math.round(clamp(rawActivityScore, 1.0, 10.0) * 10) / 10;

  // 7. Persoonlijke sessies analyseren
  const similarSessions = historicalSessions.filter((s) => {
    if (s.outcome === 'active' || s.outcome === 'unknown') return false;
    if (s.isBenchmark) return false;

    const matchedSpecies =
      s.targetSpecies?.includes(species) || (!s.targetSpecies || s.targetSpecies.length === 0);
    if (!matchedSpecies) return false;

    const sDate = new Date(s.startTime);
    const sHour = sDate.getHours();
    return sHour >= hoursConfig.start && sHour < hoursConfig.end;
  });

  const relevantCount = similarSessions.length;
  const confirmedCatches = similarSessions.filter((s) => s.outcome === 'catch').length;
  const skunks = similarSessions.filter((s) => s.outcome === 'skunk_confirmed').length;
  const catchRate =
    relevantCount >= 5 ? Math.round((confirmedCatches / relevantCount) * 100) : null;

  let expNote = '';
  if (relevantCount === 0) {
    expNote = 'Nog geen eigen sessies geregistreerd in dit specifieke tijdvak.';
  } else if (relevantCount < 5) {
    expNote = `${relevantCount} eigen sessie(s) in dit tijdvak (${confirmedCatches} met vangst). Onvoldoende gegevens (< 5) voor een statistisch verantwoorde kansschatting.`;
  } else {
    expNote = `${relevantCount} vergelijkbare sessies: ${confirmedCatches} met vangst, ${skunks} bevestigde nulvangst (${catchRate}% vangstsucces).`;
  }

  // Positieve en negatieve factoren
  const positiveFactors: string[] = [];
  const neutralFactors: string[] = [];
  const negativeFactors: string[] = [];

  const allFactors = [
    temperatureFactor,
    pressureFactor,
    windFactor,
    seasonFactor,
    timeOfDayFactor,
    precipitationFactor,
  ];

  for (const f of allFactors) {
    if (f.impact === 'positief') positiveFactors.push(`${f.title}: ${f.detail}`);
    else if (f.impact === 'negatief') negativeFactors.push(`${f.title}: ${f.detail}`);
    else neutralFactors.push(`${f.title}: ${f.detail}`);
  }

  // Conclusie
  let conclusion = '';
  if (activityScore >= 8.5) {
    conclusion = `Zeer gunstige biologische omstandigheden (${activityScore}/10) voor ${species}. Optimale samenkomst van watertemperatuur, licht en weersomstandigheden.`;
  } else if (activityScore >= 6.8) {
    conclusion = `Gunstige omstandigheden (${activityScore}/10). Voldoende biologische stimulans voor ${species}.`;
  } else if (activityScore >= 4.8) {
    conclusion = `Gemiddelde biologische activiteit (${activityScore}/10). ${
      thermalEff < 0.5 ? 'De relatief lage temperatuur tempert de stofwisseling.' : 'Enkele omstandigheden dempen het potentieel.'
    }`;
  } else {
    conclusion = `Lage biologische activiteit (${activityScore}/10). ${
      thermalEff < 0.4
        ? `Lage temperatuur (${effectiveTemp.toFixed(1)} °C) dwingt ${species} tot een inactieve winterstand.`
        : 'Voorwaarden zijn momenteel biologisch ongunstig.'
    }`;
  }

  return {
    slot,
    timeRange: hoursConfig.rangeLabel,
    activityScore,
    isPast,
    remainingHours,
    temperatureFactor,
    pressureFactor,
    windFactor,
    seasonFactor,
    timeOfDayFactor,
    precipitationFactor,
    personalExperience: {
      relevantSessions: relevantCount,
      confirmedCatches,
      skunks,
      catchRatePercent: catchRate,
      note: expNote,
    },
    positiveFactors,
    neutralFactors,
    negativeFactors,
    conclusion,
  };
}

export interface PrognosisOptions {
  sessionDurationHours?: number;
  locationId?: string;
  location?: FishingLocation;
  technique?: string;
  presenceObservation?: PresenceObservationType;
}

/**
 * Berekent de volledige dagprognose met strikte scheiding van:
 * 1. Biologische activiteitsindex (1.0 - 10.0, relatieve indicatie)
 * 2. Persoonlijke vangstkans (P(vangst >= 1) voor sessie van opgegeven duur en methode)
 * 3. Beste toekomstige vistijd (uitsluitend niet-verstreken tijdvakken)
 */
export function calculateDayPrognosis(
  dateStr: string,
  forecasts: WeatherHourlyForecast[],
  species: FishSpecies | 'Algemeen',
  historicalSessions: FishingSession[],
  weatherUpdatedAt?: string,
  userWaterTemp?: number | null,
  currentDateRef: Date = new Date(),
  options?: PrognosisOptions
): DayPrognosis {
  const rawDuration = options?.sessionDurationHours;
  const sessionDuration =
    typeof rawDuration === 'number' && !isNaN(rawDuration) && rawDuration > 0
      ? Math.min(24, Math.max(0.25, rawDuration))
      : 3;
  const locationId = options?.locationId;
  const location = options?.location;
  const presenceObs = options?.presenceObservation ?? 'onbekend';

  // Thermische analyse van het viswater
  const thermalAnalysis = analyzeWaterThermalDevelopment(dateStr, forecasts, {
    location,
    userMeasuredWaterTemp: userWaterTemp,
    historicalSessions,
  });

  const date = new Date(dateStr);
  const actualSpecies = species === 'Algemeen' ? 'Overig' : species;
  const profile = SPECIES_PROFILES[actualSpecies];

  // Filter forecasts voor deze datum (YYYY-MM-DD)
  const dayForecasts = forecasts.filter((h) => h.time.startsWith(dateStr));

  // Verdeel over 4 tijdvakken
  const slots: TimeSlot[] = ['Nacht', 'Ochtend', 'Middag', 'Avond'];
  const timeSlotAnalyses: Record<TimeSlot, TimeSlotAnalysis> = {} as any;

  for (const slot of slots) {
    const hoursConfig = TIME_SLOT_HOURS[slot];
    const slotForecasts = dayForecasts.filter((h) => {
      const hour = parseInt(h.time.slice(11, 13), 10);
      return hour >= hoursConfig.start && hour < hoursConfig.end;
    });

    timeSlotAnalyses[slot] = analyzeTimeSlot(
      slot,
      slotForecasts,
      forecasts,
      actualSpecies,
      profile,
      date,
      historicalSessions,
      currentDateRef,
      userWaterTemp,
      presenceObs
    );
  }

  // Beste toekomstige tijdvak
  const futureOrActiveSlots = slots.filter((slot) => !timeSlotAnalyses[slot].isPast);

  let bestSlot: TimeSlot | 'Geen toekomstig tijdvak meer vandaag' = 'Geen toekomstig tijdvak meer vandaag';
  let alternativeSlots: TimeSlot[] = [];

  if (futureOrActiveSlots.length > 0) {
    const sortedFuture = [...futureOrActiveSlots].sort(
      (a, b) => timeSlotAnalyses[b].activityScore - timeSlotAnalyses[a].activityScore
    );
    bestSlot = sortedFuture[0];
    alternativeSlots = sortedFuture.slice(1);
  }

  const allSlotScores = slots.map((s) => timeSlotAnalyses[s].activityScore);
  const dayScore =
    Math.round((allSlotScores.reduce((sum, v) => sum + v, 0) / allSlotScores.length) * 10) / 10;

  let advice: 'Gunstig' | 'Gemiddeld' | 'Ongunstig' = 'Gemiddeld';
  if (dayScore >= 7.0) advice = 'Gunstig';
  else if (dayScore < 4.5) advice = 'Ongunstig';

  // --- STATISTISCHE VANGSTKANS BEREKENING (SECTIE 4) ---
  // 1. Algemene basisfrequentie (Base Rate)
  const validCompletedSessions = historicalSessions.filter(
    (s) =>
      (s.outcome === 'catch' || s.outcome === 'skunk_confirmed') &&
      !s.isBenchmark
  );

  const targetSessions = validCompletedSessions.filter((s) => {
    if (species !== 'Algemeen') {
      if (!s.targetSpecies || !s.targetSpecies.includes(species)) {
        return false;
      }
    }
    return true;
  });

  const baseRate =
    targetSessions.length > 0
      ? Math.round(
          (targetSessions.filter((s) => s.outcome === 'catch').length / targetSessions.length) * 100
        )
      : null;

  // 2. Vergelijkbare sessies (soort, stek, duur, omstandigheden)
  // Als een specifieke stek is gekozen, tellen uitsluitend sessies op exact die stek mee.
  const comparableSessions = targetSessions.filter((s) => {
    if (locationId && s.locationId !== locationId) {
      return false;
    }
    return true;
  });

  const sessionCount = comparableSessions.length;
  let catchChance: number | null = null;
  let confidence: 'Onvoldoende gegevens' | 'Zeer laag' | 'Laag' | 'Matig' | 'Redelijk' | 'Gemiddeld' | 'Hoog' =
    'Onvoldoende gegevens';
  let uncertaintyInterval: [number, number] | null = null;
  let avgDurationMinutes: number | undefined = undefined;
  let expectedCatches: number | null = null;
  let hourlyCatchRate: number | null = null;

  const uncertaintyNotes: string[] = [];

  // Minimum 5 vergelijkbare sessies vereist om schijnnauwkeurigheid te voorkomen
  if (sessionCount >= 5) {
    const catchSessionsCount = comparableSessions.filter((s) => s.outcome === 'catch').length;
    const rawProportion = catchSessionsCount / sessionCount;

    // 95% Wilson Score Interval op de binomiale proportie van historische basissessies
    uncertaintyInterval = calculateWilsonInterval(catchSessionsCount, sessionCount);

    const totalDur = comparableSessions.reduce((acc, s) => acc + (s.durationMinutes || 180), 0);
    avgDurationMinutes = Math.round(totalDur / sessionCount);

    // Duurcorrectie via Poisson exposure model:
    // P(>= 1 vangst in duur t) = 1 - exp(-lambda * t)
    // waarbij lambda berekend wordt uit de gemiddelde sessieduur t_ref
    const refHours = Math.max(1, (avgDurationMinutes || 180) / 60);
    // Om log(0) bij 100% te voorkomen begrenzen we uitsluitend de bovenkant op 0.98.
    // De ondergrens is eerlijk 0 (geen gefabriceerde 5% vloer als er 0 vissen gevangen zijn).
    const safeProp = Math.max(0, Math.min(0.98, rawProportion));
    const lambdaPerHour = safeProp > 0 ? -Math.log(1 - safeProp) / refHours : 0;

    let durationAdjusted = lambdaPerHour > 0 ? 1 - Math.exp(-lambdaPerHour * sessionDuration) : 0;

    // Activiteitsmodulatie (max +/- 10% invloed op basiskans)
    const actFactor = 0.88 + (dayScore / 10) * 0.24;
    durationAdjusted = clamp(durationAdjusted * actFactor, 0, 0.95);

    // Bereken verwacht aantal vangsten over de geplande sessieduur: E[N] = lambda_eff * t
    // Vangsttempo per uur (lambdaPerHour) blijft constant over de sessieduur;
    // alleen de totale verwachte vangst en cumulatieve kans stijgen met de tijd.
    hourlyCatchRate = Math.round(lambdaPerHour * 100) / 100;
    expectedCatches = Math.round(lambdaPerHour * actFactor * sessionDuration * 10) / 10;

    // Viswaarneming invloed (+5% als vis daadwerkelijk is waargenomen)
    // Behandeld als onbevestigde modelaanname (nog niet empirisch gevalideerd)
    let appliedPresenceBonus = false;
    if (
      ['vis_springen_rollen', 'aasbellen_voedselactiviteit', 'aanbeten', 'recente_vangst_stek'].includes(
        presenceObs
      )
    ) {
      if (durationAdjusted > 0) {
        durationAdjusted = clamp(durationAdjusted + 0.05, 0, 0.95);
        appliedPresenceBonus = true;
      }
    }

    catchChance = Math.round(durationAdjusted * 100);

    // Betrouwbaarheidslabel
    if (sessionCount >= 30) confidence = 'Hoog';
    else if (sessionCount >= 18) confidence = 'Redelijk';
    else if (sessionCount >= 10) confidence = 'Matig';
    else confidence = 'Laag';

    uncertaintyNotes.push(
      `Het Wilson-betrouwbaarheidsinterval [${uncertaintyInterval[0]}% – ${uncertaintyInterval[1]}%] kwantificeert de binomiale steekproefvariantie van het historische basissessie-succes bij N=${sessionCount}. Dit is géén betrouwbaarheidsinterval rond de Poisson-duurkans, maar toont de bandbreedte van de historische basisfrequentie.`
    );

    uncertaintyNotes.push(
      `Sessieduur van ${sessionDuration} uur verwerkt via Poisson-blootstellingsmodel (gem. historische sessieduur: ${refHours.toFixed(1)} uur, vangsttempo: ${hourlyCatchRate}/uur). Cumulatieve kans stijgt niet-lineair conform P = 1 - exp(-λ × t).`
    );

    if (appliedPresenceBonus) {
      uncertaintyNotes.push(
        'De aanwezigheidsbonus (+5%) is een onbevestigde heuristische modelaanname op basis van een lokale waarneming op de stek. Deze aanname is nog niet empirisch gevalideerd.'
      );
    }
  } else {
    uncertaintyNotes.push(
      `Er zijn ${sessionCount} vergelijkbare eigen sessies in de database (minimaal 5 vereist). Een vangstpercentage en verwacht vangsttempo worden niet gefabriceerd voor de geplande sessieduur.`
    );
  }

  // Provenance
  let provenance: 'Algemene biologische regels' | 'Eigen waarnemingen' | 'Gecombineerd (model + eigen data)' | 'Algemene aannames' =
    'Algemene biologische regels';
  if (sessionCount >= 5) {
    provenance = 'Gecombineerd (model + eigen data)';
  }

  // Datum & dagnaam
  const todayStr = currentDateRef.toISOString().slice(0, 10);
  const tomorrow = new Date(currentDateRef);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().slice(0, 10);

  let dayName = '';
  if (dateStr === todayStr) {
    dayName = 'Vandaag';
  } else if (dateStr === tomorrowStr) {
    dayName = 'Morgen';
  } else {
    dayName = new Intl.DateTimeFormat('nl-NL', { weekday: 'long', day: 'numeric', month: 'short' }).format(date);
    dayName = dayName.charAt(0).toUpperCase() + dayName.slice(1);
  }

  // Samenvatting
  let summaryRationale = '';
  if (bestSlot !== 'Geen toekomstig tijdvak meer vandaag') {
    const bestSlotAnalysis = timeSlotAnalyses[bestSlot];
    summaryRationale = `Beste toekomstige vistijd is ${bestSlot} (${bestSlotAnalysis.activityScore}/10). ${bestSlotAnalysis.conclusion}`;
  } else {
    summaryRationale = 'Alle tijdvakken voor vandaag zijn inmiddels verstreken. Bekijk de prognose voor morgen.';
  }

  // Onzekerheden
  if (typeof userWaterTemp !== 'number' || isNaN(userWaterTemp)) {
    uncertaintyNotes.push(
      'Watertemperatuur is niet gemeten; de berekening gebruikt de luchttemperatuur met verhoogde thermische onzekerheid.'
    );
  }
  const midDaySample = dayForecasts[Math.floor(dayForecasts.length / 2)];
  const presTrend = findPressureTrend(midDaySample?.time || `${dateStr}T12:00`, forecasts);
  if (!presTrend.known) {
    uncertaintyNotes.push('Luchtdruktrend over de voorafgaande 12-24 uur is niet beschikbaar in de weerdataset.');
  }

  // Aanwezigheidsnotitie
  let presenceInfo: { observation: PresenceObservationType; note: string } | undefined = undefined;
  if (presenceObs !== 'onbekend') {
    let obsNote = '';
    switch (presenceObs) {
      case 'vis_springen_rollen':
        obsNote = 'Vis zien springen/rollen bevestigt dat vis fysiek aanwezig is op de stek. Dit verhoogt de lokale aanwezigheidskans, maar garandeert geen aasopname.';
        break;
      case 'aasbellen_voedselactiviteit':
        obsNote = 'Aasbellen en bodemwoelingen duiden op actieve voedselzoektocht in de bodemlaag.';
        break;
      case 'aanbeten':
        obsNote = 'Recente aanbeten of lijnzwemmers tonen aan dat vis actief in de buurt van de aasaanbieding foerageert.';
        break;
      case 'recente_vangst_stek':
        obsNote = 'Recente vangst op deze stek bevestigt actuele bezetting van de waterzone.';
        break;
      case 'geen_waarnemingen':
        obsNote = 'Geen activiteit waargenomen aan de oppervlakte. Dit is nadrukkelijk GEEN bewijs van afwezigheid (vis foerageert vaak diep of geruisloos).';
        break;
      default:
        obsNote = 'Geen viswaarnemingen gerapporteerd.';
    }
    presenceInfo = {
      observation: presenceObs,
      note: obsNote,
    };
  }

  // Tactische hengelpositionering & visbeweging (volledig gescheiden van vangstkans/activiteit)
  const positioningAdvice = analyzeRodPositioning(dateStr, forecasts, species, {
    location,
    userWaterTemp,
    thermalAnalysis,
    historicalSessions,
    targetSlot: bestSlot !== 'Geen toekomstig tijdvak meer vandaag' ? (bestSlot as TimeSlot) : undefined,
  });

  return {
    date: dateStr,
    dayName,
    species,
    activityScore: dayScore,
    advice,
    bestTimeSlot: bestSlot,
    alternativeTimeSlots: alternativeSlots,
    summaryRationale,
    personalCatchChance: catchChance,
    personalCatchConfidence: confidence,
    catchUncertaintyInterval: uncertaintyInterval,
    relevantSessionCount: sessionCount,
    averageRelevantSessionDurationMin: avgDurationMinutes,
    plannedDurationHours: sessionDuration,
    expectedCatches,
    hourlyCatchRate,
    baseRate,
    provenance,
    weatherUpdatedAt,
    timeSlots: timeSlotAnalyses,
    uncertaintyNotes,
    waterTemperatureInfo: {
      measured: typeof userWaterTemp === 'number' && !isNaN(userWaterTemp),
      temp: typeof userWaterTemp === 'number' && !isNaN(userWaterTemp) ? userWaterTemp : null,
      note:
        typeof userWaterTemp === 'number' && !isNaN(userWaterTemp)
          ? `Gemeten watertemperatuur: ${userWaterTemp} °C (directe stekmeting).`
          : thermalAnalysis.estimatedWaterTemp !== null
          ? `Watertemperatuur niet gemeten; modelschatting is ~${thermalAnalysis.estimatedWaterTemp} °C (bereik [${thermalAnalysis.estimatedRange?.[0]}–${thermalAnalysis.estimatedRange?.[1]} °C], trend: ${thermalAnalysis.trend.toLowerCase()}).`
          : 'Geen watertemperatuur gemeten; 2m-luchttemperatuur gebruikt met verhoogde thermische onzekerheid.',
    },
    pressureTrendInfo: {
      known: presTrend.known,
      deltaHpa: presTrend.deltaHpa,
      note: presTrend.trendDescription,
    },
    presenceInfo,
    thermalAnalysis,
    positioningAdvice,
  };
}

/**
 * Slaat een onveranderlijke (immutable) voorspellingsmomentopname op in Dexie voor latere empirische evaluatie.
 * Voorkomt dubbele snapshots door te controleren of er al een onveranderlijke momentopname voor dit tijdvak bestaat.
 */
export async function savePrognosisSnapshot(
  prognosis: DayPrognosis,
  durationHours: number,
  locationId?: string,
  locationName?: string,
  technique?: string,
  chosenSlot?: TimeSlot
): Promise<PrognosisSnapshot> {
  const targetSlot =
    chosenSlot ||
    (prognosis.bestTimeSlot !== 'Geen toekomstig tijdvak meer vandaag'
      ? (prognosis.bestTimeSlot as TimeSlot)
      : 'Ochtend');

  // Controleer of er al een onveranderlijke, nog niet-gekoppelde momentopname bestaat
  // voor exact deze doeldatum, tijdvak, vissoort en locatie om duplicaten te voorkomen
  const existingList = await db.prognosisSnapshots.toArray();
  const existing = existingList.find(
    (s) =>
      s.targetDate === prognosis.date &&
      s.targetSlot === targetSlot &&
      s.targetSpecies === prognosis.species &&
      (locationId ? s.locationId === locationId : true) &&
      !s.linkedSessionId
  );

  if (existing) {
    // Behoud de reeds opgeslagen momentopname ongewijzigd (evaluatie-integriteit & immutability)
    return existing;
  }

  const id = `snapshot-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const snapshot: PrognosisSnapshot = {
    id,
    forecastTimestamp: new Date().toISOString(),
    targetDate: prognosis.date,
    targetSlot,
    targetSpecies: prognosis.species,
    locationId,
    locationName,
    durationHours,
    technique,
    predictedActivityScore: prognosis.activityScore,
    predictedCatchChance: prognosis.personalCatchChance,
    predictedUncertaintyInterval: prognosis.catchUncertaintyInterval,
    predictedConfidence: prognosis.personalCatchConfidence,
    modelVersion: 'v2.2',
    source: 'Vislogboek v2.2 Prognose-Engine',
    createdAt: new Date().toISOString(),
  };

  await db.prognosisSnapshots.put(snapshot);
  return snapshot;
}
