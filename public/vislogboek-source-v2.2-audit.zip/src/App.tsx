import React, { useState, useEffect } from 'react';
import { db, initializeDatabase } from './db/db';
import { FishingLocation, FishingSession, CatchItem, FishSpecies } from './types';
import { Navbar, TabType } from './components/Navbar';
import { PrognosisView } from './components/prognosis/PrognosisView';
import { SessionsView } from './components/sessions/SessionsView';
import { LocationsView } from './components/locations/LocationsView';
import { StatsView } from './components/stats/StatsView';
import { WeatherView } from './components/weather/WeatherView';
import { SettingsView } from './components/settings/SettingsView';
import { SessionModal } from './components/sessions/SessionModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import {
  Compass,
  Clock,
  Play,
  WifiOff,
  Sparkles,
  ShieldCheck,
  Fish,
} from 'lucide-react';

export default function App() {
  const isOnline = useOnlineStatus();
  const [currentTab, setCurrentTab] = useState<TabType>('prognosis');
  const [loading, setLoading] = useState<boolean>(true);
  const [locations, setLocations] = useState<FishingLocation[]>([]);
  const [sessions, setSessions] = useState<FishingSession[]>([]);
  const [catches, setCatches] = useState<CatchItem[]>([]);
  const [isStartingSession, setIsStartingSession] = useState<boolean>(false);
  const [prefilledSpecies, setPrefilledSpecies] = useState<FishSpecies | undefined>(undefined);
  const [prefilledLocationId, setPrefilledLocationId] = useState<string | undefined>(undefined);

  const loadData = async () => {
    try {
      await initializeDatabase();
      const [allLocations, allSessions, allCatches] = await Promise.all([
        db.locations.toArray(),
        db.sessions.reverse().sortBy('startTime'),
        db.catches.reverse().sortBy('timestamp'),
      ]);
      setLocations(allLocations);
      setSessions(allSessions);
      setCatches(allCatches);
    } catch (err) {
      console.error('Fout bij laden van Vislogboek data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const activeSessions = sessions.filter((s) => s.outcome === 'active');

  const handleStartSession = (species?: FishSpecies, locationId?: string) => {
    setPrefilledSpecies(species);
    setPrefilledLocationId(locationId);
    setIsStartingSession(true);
  };

  const handleSaveSession = async (sessionData: Partial<FishingSession>) => {
    if (sessionData.id) {
      const existing = await db.sessions.get(sessionData.id);
      if (existing) {
        await db.sessions.update(sessionData.id, sessionData);
      } else {
        await db.sessions.put(sessionData as FishingSession);
      }
    }
    await loadData();
  };

  const handleSaveCatch = async (catchData: CatchItem) => {
    await db.catches.put(catchData);
    // Werk automatisch sessie status bij naar 'catch' indien van toepassing
    const sess = await db.sessions.get(catchData.sessionId);
    if (sess && (sess.outcome === 'skunk_confirmed' || sess.outcome === 'unknown')) {
      await db.sessions.update(catchData.sessionId, {
        outcome: 'catch',
        updatedAt: new Date().toISOString(),
      });
    }
    await loadData();
  };

  const handleSaveLocation = async (locData: FishingLocation) => {
    await db.locations.put(locData);
    await loadData();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-slate-200">
        <div className="w-14 h-14 rounded-2xl bg-emerald-600/30 border border-emerald-500 flex items-center justify-center animate-pulse mb-4">
          <Fish className="w-8 h-8 text-emerald-400" />
        </div>
        <h2 className="text-xl font-black text-white">Vislogboek</h2>
        <p className="text-xs text-slate-400 mt-1">Lokale database initialiseren...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-emerald-600 selection:text-white">
      {/* Offline Status Indicator Banner */}
      {!isOnline && (
        <div className="bg-amber-600 px-4 py-2 text-center text-xs font-bold text-white flex items-center justify-center gap-2 shadow-md">
          <WifiOff className="w-4 h-4 shrink-0" />
          <span>Offline modus actief — Vislogboek werkt lokaal door met gecachete gegevens.</span>
        </div>
      )}

      {/* Header Bar */}
      <header className="sticky top-0 z-30 bg-slate-900/90 border-b border-slate-800/80 backdrop-blur-md px-4 sm:px-6 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
          {/* Brand Logo & Name */}
          <div
            onClick={() => setCurrentTab('prognosis')}
            className="flex items-center gap-3 cursor-pointer select-none group"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 p-0.5 shadow-lg shadow-emerald-950/60 group-hover:scale-105 transition">
              <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
                <Fish className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <span className="text-lg font-black text-white tracking-tight leading-none block">
                Vislogboek
              </span>
              <span className="text-[10px] text-emerald-400/90 font-bold uppercase tracking-wider block mt-0.5">
                Prognose & Sessies
              </span>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <Navbar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            activeSessionCount={activeSessions.length}
          />

          {/* Header Right Actions */}
          <div className="flex items-center gap-2.5">
            {/* Actieve sessie pill indicator */}
            {activeSessions.length > 0 && (
              <button
                onClick={() => setCurrentTab('sessions')}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold animate-pulse hover:bg-emerald-500/30 transition cursor-pointer"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                {activeSessions.length} actieve sessie
              </button>
            )}

            {/* In-app PWA install button */}
            <PWAInstallButton />

            {/* Snelle Sessie Starten Knop */}
            <button
              onClick={() => handleStartSession()}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md transition active:scale-95 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span className="hidden sm:inline">Start</span> Sessie
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 px-4 sm:px-6 py-6 pb-24 md:pb-12 max-w-6xl mx-auto w-full">
        {currentTab === 'prognosis' && (
          <PrognosisView
            locations={locations}
            sessions={sessions}
            onStartSession={handleStartSession}
          />
        )}

        {currentTab === 'sessions' && (
          <SessionsView
            sessions={sessions}
            catches={catches}
            locations={locations}
            onRefreshData={loadData}
            onStartNewSession={() => handleStartSession()}
            onSaveSession={handleSaveSession}
            onSaveCatch={handleSaveCatch}
          />
        )}

        {currentTab === 'locations' && (
          <LocationsView
            locations={locations}
            sessions={sessions}
            catches={catches}
            onRefreshData={loadData}
            onSaveLocation={handleSaveLocation}
          />
        )}

        {currentTab === 'stats' && (
          <StatsView
            sessions={sessions}
            catches={catches}
            locations={locations}
          />
        )}

        {currentTab === 'weather' && (
          <WeatherView locations={locations} />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            locations={locations}
            sessions={sessions}
            catches={catches}
            onRefreshData={loadData}
          />
        )}
      </main>

      {/* Modal voor nieuwe sessie starten vanaf header of prognosescherm */}
      {isStartingSession && (
        <SessionModal
          locations={locations}
          session={
            prefilledLocationId || prefilledSpecies
              ? ({
                  id: 'session_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
                  locationId: prefilledLocationId || locations[0]?.id,
                  targetSpecies: prefilledSpecies ? [prefilledSpecies] : ['Karper'],
                  startTime: new Date().toISOString(),
                  outcome: 'active',
                  rodCount: 2,
                  technique: 'Feeder / Statisch',
                  baitAndFeed: 'Boilies, maden & mais',
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                } as FishingSession)
              : null
          }
          onSave={async (newSess) => {
            await handleSaveSession(newSess);
            setCurrentTab('sessions');
            setIsStartingSession(false);
          }}
          onClose={() => setIsStartingSession(false)}
        />
      )}
    </div>
  );
}
