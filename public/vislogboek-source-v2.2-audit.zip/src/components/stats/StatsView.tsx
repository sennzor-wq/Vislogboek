import React, { useState, useEffect } from 'react';
import {
  FishingSession,
  CatchItem,
  FishingLocation,
  FishSpecies,
  ALL_SPECIES,
  SessionOutcome,
  PrognosisSnapshot,
} from '../../types';
import { calculateStats, StatsFilter } from '../../services/statsEngine';
import { evaluatePrognosisPerformance, EvaluationResult } from '../../services/evaluationEngine';
import { db } from '../../db/db';
import {
  BarChart3,
  Fish,
  Clock,
  TrendingUp,
  MapPin,
  Calendar,
  Filter,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Scale,
  Sparkles,
  Info,
  ShieldCheck,
  Award,
  BookmarkPlus,
  AlertCircle,
} from 'lucide-react';

interface StatsViewProps {
  sessions: FishingSession[];
  catches: CatchItem[];
  locations: FishingLocation[];
}

export const StatsView: React.FC<StatsViewProps> = ({ sessions, catches, locations }) => {
  const [filter, setFilter] = useState<StatsFilter>({
    species: 'Alle',
    locationId: undefined,
    outcome: 'Alle',
  });

  const [snapshots, setSnapshots] = useState<PrognosisSnapshot[]>([]);
  const [evaluation, setEvaluation] = useState<EvaluationResult | null>(null);

  useEffect(() => {
    const loadSnapshots = async () => {
      try {
        const list = await db.prognosisSnapshots.toArray();
        setSnapshots(list);
        const evalRes = evaluatePrognosisPerformance(list);
        setEvaluation(evalRes);
      } catch (e) {
        console.error('Fout bij laden prognose momentopnames:', e);
      }
    };
    loadSnapshots();
  }, [sessions]);

  const { overall, speciesStats, locationStats, timeSlotStats } = calculateStats(
    sessions,
    catches,
    filter
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-emerald-400" />
          Statistieken & Vangstanalyses
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
          Objectieve analyse van jouw eigen vissessies, technieken en viswateren.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-300 uppercase tracking-wider">
          <Filter className="w-4 h-4 text-emerald-400" />
          <span>Statistieken Filteren</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Vissoort</label>
            <select
              value={filter.species || 'Alle'}
              onChange={(e) => setFilter({ ...filter, species: e.target.value as any })}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
            >
              <option value="Alle">Alle vissoorten</option>
              {ALL_SPECIES.map((sp) => (
                <option key={sp} value={sp}>
                  {sp}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Locatie</label>
            <select
              value={filter.locationId || ''}
              onChange={(e) =>
                setFilter({ ...filter, locationId: e.target.value ? e.target.value : undefined })
              }
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
            >
              <option value="">Alle locaties</option>
              {locations.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Uitkomst</label>
            <select
              value={filter.outcome || 'Alle'}
              onChange={(e) => setFilter({ ...filter, outcome: e.target.value as any })}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
            >
              <option value="Alle">Alle uitkomsten</option>
              <option value="catch">Alleen met vangst</option>
              <option value="skunk_confirmed">Alleen bevestigde nulvangsten</option>
            </select>
          </div>
        </div>
      </div>

      {/* KPI Kaarten Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/70">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Totaal Sessies
          </span>
          <span className="text-2xl sm:text-3xl font-black text-white">{overall.totalSessions}</span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            ({overall.completedSessions} afgerond, {overall.activeSessions} actief)
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/70">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Gevangen Vissen
          </span>
          <span className="text-2xl sm:text-3xl font-black text-emerald-400">
            {overall.totalFishCaught}
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            {overall.catchesPerHour.toFixed(2)} vis per uur
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/70">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Vangstpercentage
          </span>
          <span className="text-2xl sm:text-3xl font-black text-cyan-300">
            {overall.successRatePercent !== null ? `${overall.successRatePercent}%` : 'N.v.t.'}
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            {overall.catchSessions} van {overall.catchSessions + overall.confirmedSkunks} geldige sessies
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/70">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Totale Visduur
          </span>
          <span className="text-2xl sm:text-3xl font-black text-white">
            {(overall.totalDurationMinutes / 60).toFixed(1)} u
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Gem. {overall.averageDurationMinutes} min per sessie
          </span>
        </div>
      </div>

      {/* Uitkomsten Vergelijking */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-800/70 border border-slate-700/70 space-y-3">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">
          Sessie-uitkomsten Vergelijking
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/40 flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-bold">Sessies met Vangst</span>
            </div>
            <span className="text-base font-black text-white">{overall.catchSessions}</span>
          </div>

          <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-800/40 flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-300">
              <XCircle className="w-4 h-4 text-amber-400" />
              <span className="font-bold">Bevestigde Nulvangsten</span>
            </div>
            <span className="text-base font-black text-white">{overall.confirmedSkunks}</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300">
              <HelpCircle className="w-4 h-4 text-slate-400" />
              <span className="font-bold">Onbekende Uitkomsten</span>
            </div>
            <span className="text-base font-black text-white">{overall.unknownOutcomes}</span>
          </div>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          * Actieve en onbekende sessies zijn expliciet uitgesloten van vangstpercentages om schijnnauwkeurigheid te voorkomen.
        </p>
      </div>

      {/* MODELVALIDATIE & BRIER-SCORE EVALUATIE (SECTIE 7 V2.2) */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-slate-850 via-slate-900 to-slate-950 border border-slate-700/80 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
              Modelvalidatie & Empirische Brier-score (v2.2)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Toetst of voorspelde vangstkansen daadwerkelijk overeenkomen met gerealiseerde sessies.
            </p>
          </div>
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-cyan-950/60 text-cyan-300 border border-cyan-800/50 self-start sm:self-center">
            {snapshots.length} momentopname(s) geregistreerd
          </span>
        </div>

        {evaluation && (
          <div className="space-y-4">
            {/* Status & Scores Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              {/* Brier Score */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/60">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Brier-score (BS)
                </span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl sm:text-3xl font-black text-white">
                    {evaluation.brierScore !== null ? evaluation.brierScore.toFixed(3) : 'Geen data'}
                  </span>
                  <span className="text-xs text-slate-400">(0.000 = perfect)</span>
                </div>
                <span className="text-[11px] text-slate-400 block mt-1">
                  {evaluation.hasSufficientData
                    ? evaluation.brierScore! < 0.18
                      ? 'Goede kalibratie van vangstkansen'
                      : 'Gemiddelde afwijking ten opzichte van uitkomst'
                    : 'Vereist minimaal 5 gerealiseerde momentopnames'}
                </span>
              </div>

              {/* Naive Baseline */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/60">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Naïeve Baseline (BS_naive)
                </span>
                <span className="text-2xl sm:text-3xl font-black text-slate-300">
                  {evaluation.naiveBrierScore !== null
                    ? evaluation.naiveBrierScore.toFixed(3)
                    : 'Geen data'}
                </span>
                <span className="text-[11px] text-slate-400 block mt-1">
                  Vergelijkt model met een vaste steekproef-basiskans ({evaluation.observedCatchRate ?? '—'}%)
                </span>
              </div>

              {/* Brier Skill Score */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/60">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Brier Skill Score (BSS)
                </span>
                <span
                  className={`text-2xl sm:text-3xl font-black ${
                    evaluation.brierSkillScore !== null && evaluation.brierSkillScore > 0
                      ? 'text-emerald-400'
                      : 'text-amber-400'
                  }`}
                >
                  {evaluation.brierSkillScore !== null
                    ? `${(evaluation.brierSkillScore * 100).toFixed(1)}%`
                    : 'Geen data'}
                </span>
                <span className="text-[11px] text-slate-400 block mt-1">
                  {evaluation.brierSkillScore !== null && evaluation.brierSkillScore > 0
                    ? 'Model voorspelt beter dan vaste basiskans'
                    : 'Geen statistische meerwaarde aangetoond t.o.v. baseline'}
                </span>
              </div>
            </div>

            {/* Kalibratietabel */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Kalibratie per Kanskwartiel (Voorspelde kans vs. Werkelijke uitkomst)
              </h4>
              <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/80 text-slate-300 font-semibold border-b border-slate-700">
                    <tr>
                      <th className="p-3">Kanssegment</th>
                      <th className="p-3">Aantal Momentopnames</th>
                      <th className="p-3">Gem. Voorspelde Kans</th>
                      <th className="p-3">Gerealiseerde Vangstfractie</th>
                      <th className="p-3">Kalibratieverschil (Delta)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    {evaluation.calibrationBins.map((bin) => (
                      <tr key={bin.rangeLabel} className="hover:bg-slate-800/40">
                        <td className="p-3 font-medium text-white">{bin.rangeLabel}</td>
                        <td className="p-3">{bin.snapshotCount}</td>
                        <td className="p-3">
                          {bin.averageForecastProb !== null ? `${bin.averageForecastProb}%` : '—'}
                        </td>
                        <td className="p-3">
                          {bin.observedCatchFraction !== null
                            ? `${bin.observedCatchFraction}%`
                            : '—'}
                        </td>
                        <td className="p-3">
                          {bin.calibrationDelta !== null ? (
                            <span
                              className={`font-semibold ${
                                Math.abs(bin.calibrationDelta) <= 15
                                  ? 'text-emerald-400'
                                  : 'text-amber-400'
                              }`}
                            >
                              {bin.calibrationDelta > 0 ? `+${bin.calibrationDelta}%` : `${bin.calibrationDelta}%`}
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Disclaimers & Eerlijke statusmelding */}
            <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1.5 text-xs text-slate-400">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-cyan-400" />
                Validatiestatus: {evaluation.statusMessage}
              </span>
              <ul className="list-disc pl-5 space-y-1 text-[11px] text-slate-400">
                {evaluation.disclaimers.map((disc, idx) => (
                  <li key={idx}>{disc}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Vangsten per Soort & Tijdvak Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Soortstatistieken */}
        <div className="p-5 rounded-3xl bg-slate-800/70 border border-slate-700/70 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Fish className="w-5 h-5 text-emerald-400" />
            Vangsten per Vissoort
          </h3>

          {speciesStats.length === 0 ? (
            <p className="text-xs text-slate-400 italic">Nog geen vangsten geregistreerd.</p>
          ) : (
            <div className="space-y-2.5">
              {speciesStats.map((sp) => {
                const maxCount = Math.max(...speciesStats.map((s) => s.count), 1);
                const percent = Math.round((sp.count / maxCount) * 100);

                return (
                  <div key={sp.species} className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800">
                    <div className="flex items-center justify-between text-xs font-semibold mb-1">
                      <span className="text-white">{sp.species}</span>
                      <span className="text-emerald-400 font-bold">
                        {sp.count} vis{sp.count === 1 ? '' : 'sen'}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
                      <div
                        className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>
                        Max gewicht: {sp.maxWeightKg !== null ? `${sp.maxWeightKg} kg` : 'N.v.t.'}
                      </span>
                      <span>
                        Totaal gewogen:{' '}
                        {sp.knownWeightsCount > 0 ? `${sp.totalWeightKg.toFixed(1)} kg` : 'Ongewogen'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Tijdvakverdeling */}
        <div className="p-5 rounded-3xl bg-slate-800/70 border border-slate-700/70 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-cyan-400" />
            Productiviteit per Tijdvak
          </h3>

          <div className="grid grid-cols-2 gap-3">
            {timeSlotStats.map((ts) => (
              <div
                key={ts.slot}
                className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center"
              >
                <span className="text-xs font-bold text-slate-300 block mb-1">{ts.slot}</span>
                <span className="text-xl font-black text-cyan-300 block">
                  {ts.catchesPerHour.toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  vis/uur ({ts.fishCount} vissen / {ts.sessionCount} sessies)
                </span>
              </div>
            ))}
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/40 border border-slate-800/80 flex items-start gap-2.5 text-xs text-slate-400">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>
              <strong>Wetenschappelijke nuance:</strong> Correlatie tussen tijdvak en vangsten kan ook beïnvloed worden door jouw eigen beschikbaarheid (wanneer je vist).
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
