import React, { useState, useEffect } from 'react';
import {
  FishingSession,
  FishingLocation,
  CatchItem,
  SessionOutcome,
  FishSpecies,
} from '../../types';
import { SessionModal } from './SessionModal';
import { EndSessionModal } from './EndSessionModal';
import { CatchModal } from '../catches/CatchModal';
import { deleteSessionSafely } from '../../db/db';
import {
  Plus,
  Play,
  Square,
  Clock,
  MapPin,
  Sparkles,
  CheckCircle2,
  XCircle,
  HelpCircle,
  AlertTriangle,
  Edit2,
  Trash2,
  Calendar,
  Filter,
  Thermometer,
  Wind,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface SessionsViewProps {
  sessions: FishingSession[];
  catches: CatchItem[];
  locations: FishingLocation[];
  onRefreshData: () => Promise<void>;
  onStartNewSession: () => void;
  onSaveSession: (sessionData: Partial<FishingSession>) => Promise<void>;
  onSaveCatch: (catchData: CatchItem) => Promise<void>;
}

export const SessionsView: React.FC<SessionsViewProps> = ({
  sessions,
  catches,
  locations,
  onRefreshData,
  onStartNewSession,
  onSaveSession,
  onSaveCatch,
}) => {
  const [filterOutcome, setFilterOutcome] = useState<string>('Alle');
  const [filterLocationId, setFilterLocationId] = useState<string>('Alle');
  const [editingSession, setEditingSession] = useState<FishingSession | null>(null);
  const [endingSession, setEndingSession] = useState<FishingSession | null>(null);
  const [addingCatchForSessionId, setAddingCatchForSessionId] = useState<string | null>(null);
  const [editingCatch, setEditingCatch] = useState<CatchItem | null>(null);
  const [expandedSessionIds, setExpandedSessionIds] = useState<Set<string>>(new Set());
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Live timer tick voor actieve sessies
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 30000);
    return () => clearInterval(timer);
  }, []);

  const activeSessions = sessions.filter((s) => s.outcome === 'active');
  const completedSessions = sessions.filter((s) => s.outcome !== 'active');

  const filteredCompletedSessions = completedSessions.filter((s) => {
    if (filterOutcome !== 'Alle' && s.outcome !== filterOutcome) return false;
    if (filterLocationId !== 'Alle' && s.locationId !== filterLocationId) return false;
    return true;
  });

  const toggleExpand = (id: string) => {
    setExpandedSessionIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const calculateLiveDuration = (startTimeIso: string) => {
    const startMs = new Date(startTimeIso).getTime();
    const nowMs = Date.now();
    const diffMin = Math.max(0, Math.floor((nowMs - startMs) / 60000));
    const hours = Math.floor(diffMin / 60);
    const mins = diffMin % 60;
    return `${hours}u ${mins}m`;
  };

  const handleDeleteSession = async (sessionId: string) => {
    try {
      setErrorMessage(null);
      await deleteSessionSafely(sessionId);
      await onRefreshData();
    } catch (err: any) {
      setErrorMessage(err.message || 'Kon sessie niet verwijderen.');
    }
  };

  const handleConfirmEndSession = async (
    sessionId: string,
    outcome: SessionOutcome,
    notes?: string
  ) => {
    const session = sessions.find((s) => s.id === sessionId);
    if (!session) return;

    const endIso = new Date().toISOString();
    const startMs = new Date(session.startTime).getTime();
    const endMs = new Date(endIso).getTime();
    const diffMin = Math.max(1, Math.round((endMs - startMs) / 60000));

    await onSaveSession({
      id: sessionId,
      endTime: endIso,
      durationMinutes: diffMin,
      outcome,
      notes: notes || session.notes,
      updatedAt: endIso,
    });
    await onRefreshData();
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Foutmelding Banner (bijv. benchmarkbeveiliging) */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-700 text-rose-200 flex items-center justify-between text-xs sm:text-sm animate-fade-in">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-xs font-bold uppercase underline hover:text-white"
          >
            Sluiten
          </button>
        </div>
      )}

      {/* Header en Nieuwe Sessie Knop */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Clock className="w-6 h-6 text-emerald-400" />
            Vissessies & Logboek
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Registreer actieve sessies aan de waterkant of voeg historische visdagen toe.
          </p>
        </div>

        <button
          onClick={onStartNewSession}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-950/50 transition active:scale-95 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-white" />
          Sessie Starten
        </button>
      </div>

      {/* Actieve Sessies Sectie (kan meerdere zijn) */}
      {activeSessions.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            Actieve Sessie(s) aan het water ({activeSessions.length})
          </h2>

          <div className="grid grid-cols-1 gap-3.5">
            {activeSessions.map((session) => {
              const sessionCatches = catches.filter((c) => c.sessionId === session.id);
              const totalFish = sessionCatches.reduce((sum, c) => sum + (c.count || 1), 0);
              const liveDuration = calculateLiveDuration(session.startTime);

              return (
                <div
                  key={session.id}
                  className="rounded-3xl bg-slate-800 border-2 border-emerald-500/80 p-5 shadow-xl ring-2 ring-emerald-500/20"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-700/80">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-500/40 animate-pulse">
                          ● Nu Actief
                        </span>
                        <span className="text-base font-black text-white">
                          {session.locationName}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-300 mt-1.5 flex-wrap">
                        <span>Gestart om: {new Date(session.startTime).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}</span>
                        <span>•</span>
                        <span className="font-bold text-emerald-300">Live duur: {liveDuration}</span>
                        {session.rodCount && (
                          <>
                            <span>•</span>
                            <span>{session.rodCount} hengel(s)</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Actieknoppen Actieve Sessie */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => setAddingCatchForSessionId(session.id)}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition active:scale-95 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        Vangst registreren
                      </button>

                      <button
                        onClick={() => setEndingSession(session)}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold text-xs transition border border-slate-600 cursor-pointer"
                      >
                        <Square className="w-4 h-4 text-amber-400" />
                        Sessie afronden
                      </button>
                    </div>
                  </div>

                  {/* Vangsten in deze actieve sessie */}
                  <div className="pt-3.5">
                    <span className="text-xs font-bold text-slate-300 block mb-2">
                      Vangsten in deze sessie ({totalFish} vis{totalFish === 1 ? '' : 'sen'}):
                    </span>
                    {sessionCatches.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">
                        Nog geen vangsten geregistreerd tijdens deze sessie.
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {sessionCatches.map((c) => (
                          <div
                            key={c.id}
                            className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-center justify-between text-xs"
                          >
                            <div>
                              <span className="font-bold text-white block">
                                {c.count > 1 ? `${c.count}x ` : ''}
                                {c.species}
                              </span>
                              <span className="text-slate-400 text-[11px]">
                                {c.weightKg ? `${c.weightKg} kg` : 'Gewicht onbekend'}
                                {c.bait ? ` • ${c.bait}` : ''}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {new Date(c.timestamp).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filters voor Afgeronde Sessies */}
      <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <Filter className="w-4 h-4 text-emerald-400" />
          <span>Filter Sessies:</span>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={filterOutcome}
            onChange={(e) => setFilterOutcome(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-medium focus:ring-2 focus:ring-emerald-500"
          >
            <option value="Alle">Alle uitkomsten</option>
            <option value="catch">Alleen met vangst</option>
            <option value="skunk_confirmed">Alleen bevestigde nulvangsten</option>
            <option value="unknown">Onbekende uitkomsten</option>
          </select>

          <select
            value={filterLocationId}
            onChange={(e) => setFilterLocationId(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-medium focus:ring-2 focus:ring-emerald-500"
          >
            <option value="Alle">Alle locaties</option>
            {locations.map((loc) => (
              <option key={loc.id} value={loc.id}>
                {loc.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Lijst van Afgeronde / Historische Sessies */}
      <div className="space-y-3.5">
        <h2 className="text-sm font-bold text-slate-300 uppercase tracking-wider">
          Sessiehistorie ({filteredCompletedSessions.length})
        </h2>

        {filteredCompletedSessions.length === 0 ? (
          <div className="p-8 rounded-3xl bg-slate-800/40 border border-slate-700/50 text-center text-slate-400">
            Geen sessies gevonden die voldoen aan de geselecteerde filters.
          </div>
        ) : (
          filteredCompletedSessions.map((session) => {
            const isExpanded = expandedSessionIds.has(session.id);
            const sessionCatches = catches.filter((c) => c.sessionId === session.id);
            const totalFish = sessionCatches.reduce((sum, c) => sum + (c.count || 1), 0);

            const durationFormatted = session.durationMinutes
              ? `${Math.floor(session.durationMinutes / 60)}u ${session.durationMinutes % 60}m`
              : 'Onbekende duur';

            return (
              <div
                key={session.id}
                className={`rounded-3xl border transition overflow-hidden ${
                  session.isBenchmark
                    ? 'bg-slate-800/90 border-amber-500/50 shadow-md ring-1 ring-amber-500/20'
                    : 'bg-slate-800/70 border-slate-700/70 hover:border-slate-600'
                }`}
              >
                {/* Header Rij */}
                <div className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Uitkomst Badge */}
                      {session.outcome === 'catch' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Vangst ({totalFish} vis{totalFish === 1 ? '' : 'sen'})
                        </span>
                      ) : session.outcome === 'skunk_confirmed' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                          <XCircle className="w-3.5 h-3.5" />
                          Bevestigde nulvangst
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-700 text-slate-300">
                          <HelpCircle className="w-3.5 h-3.5" />
                          Onbekende uitkomst
                        </span>
                      )}

                      {/* Benchmark Badge */}
                      {session.isBenchmark && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-950/80 text-amber-300 border border-amber-600/50">
                          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                          Beschermde Benchmark
                        </span>
                      )}

                      <span className="text-base font-bold text-white">
                        {session.locationName}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-400 flex-wrap">
                      <span className="flex items-center gap-1 text-slate-300">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(session.startTime).toLocaleDateString('nl-NL', {
                          weekday: 'short',
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                      <span>•</span>
                      <span>
                        {new Date(session.startTime).toLocaleTimeString('nl-NL', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}{' '}
                        –{' '}
                        {session.endTime
                          ? new Date(session.endTime).toLocaleTimeString('nl-NL', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })
                          : '?'}
                      </span>
                      <span>•</span>
                      <span className="font-semibold text-slate-300">Duur: {durationFormatted}</span>
                      {session.technique && (
                        <>
                          <span>•</span>
                          <span>{session.technique}</span>
                        </>
                      )}
                      {session.rodCount && (
                        <>
                          <span>•</span>
                          <span>{Number(session.rodCount)} hengel(s)</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Knoppen & Toggle */}
                  <div className="flex items-center gap-2 self-end md:self-center">
                    <button
                      onClick={() => setAddingCatchForSessionId(session.id)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 font-semibold text-xs border border-emerald-700/40 transition cursor-pointer"
                    >
                      + Vangst
                    </button>

                    <button
                      onClick={() => setEditingSession(session)}
                      className="p-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 transition"
                      title="Sessie bewerken"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDeleteSession(session.id)}
                      className="p-2 rounded-xl bg-slate-700/60 hover:bg-rose-900/50 text-slate-300 hover:text-rose-300 transition"
                      title={session.isBenchmark ? 'Benchmark is beschermd' : 'Sessie verwijderen'}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => toggleExpand(session.id)}
                      className="p-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 transition"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Uitgebreide Sessiedetails */}
                {isExpanded && (
                  <div className="p-4 pt-1 border-t border-slate-700/60 bg-slate-900/40 space-y-3.5">
                    {/* Weersgegevens van de sessie */}
                    {session.weatherSnapshot && (
                      <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/40 flex items-center justify-between text-xs text-slate-300 flex-wrap gap-2">
                        <div className="flex items-center gap-4 flex-wrap">
                          <span className="flex items-center gap-1 font-semibold text-white">
                            <Thermometer className="w-3.5 h-3.5 text-rose-400" />
                            {session.weatherSnapshot.temperature} °C
                          </span>
                          <span>Barometer: {session.weatherSnapshot.pressure} hPa</span>
                          <span>
                            Wind: {session.weatherSnapshot.windDirectionText}{' '}
                            {session.weatherSnapshot.windSpeed} km/u
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          Bron: {session.weatherSnapshot.source}
                        </span>
                      </div>
                    )}

                    {/* Notities & Vangsten */}
                    {session.notes && (
                      <p className="text-xs text-slate-300 bg-slate-800/40 p-3 rounded-xl">
                        <strong>Notities:</strong> {session.notes}
                      </p>
                    )}

                    {/* Vangstenlijst */}
                    <div>
                      <span className="text-xs font-bold text-slate-300 block mb-2">
                        Geregistreerde Vangsten:
                      </span>
                      {sessionCatches.length === 0 ? (
                        <p className="text-xs text-slate-400 italic">
                          Geen vangsten gekoppeld aan deze sessie.
                        </p>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                          {sessionCatches.map((c) => (
                            <div
                              key={c.id}
                              className="p-3 rounded-2xl bg-slate-800/90 border border-slate-700 flex flex-col justify-between text-xs space-y-1.5"
                            >
                              <div className="flex items-start justify-between">
                                <div>
                                  <span className="font-bold text-white text-sm block">
                                    {c.count > 1 ? `${c.count}x ` : ''}
                                    {c.species}
                                  </span>
                                  <span className="text-emerald-300 font-semibold text-xs">
                                    {c.weightKg !== null && c.weightKg !== undefined
                                      ? `${c.weightKg} kg ${c.isGroupWeight ? '(totaal)' : ''}`
                                      : 'Gewicht onbekend'}
                                  </span>
                                </div>
                                {c.photoUrl && (
                                  <img
                                    src={c.photoUrl}
                                    alt={c.species}
                                    className="w-10 h-10 object-cover rounded-lg border border-slate-600"
                                  />
                                )}
                              </div>

                              <div className="text-[11px] text-slate-400 space-y-0.5">
                                {c.bait && <div>Aas: {c.bait}</div>}
                                {c.notes && <div>{c.notes}</div>}
                              </div>

                              <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-700/50 flex justify-between">
                                <span>{new Date(c.timestamp).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}</span>
                                <button
                                  onClick={() => setEditingCatch(c)}
                                  className="text-slate-400 hover:text-white underline cursor-pointer"
                                >
                                  Bewerken
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Modals */}
      {editingSession && (
        <SessionModal
          session={editingSession}
          locations={locations}
          onSave={async (updated) => {
            await onSaveSession(updated);
            await onRefreshData();
          }}
          onClose={() => setEditingSession(null)}
        />
      )}

      {endingSession && (
        <EndSessionModal
          session={endingSession}
          hasCatches={catches.some((c) => c.sessionId === endingSession.id)}
          onConfirmEnd={handleConfirmEndSession}
          onClose={() => setEndingSession(null)}
        />
      )}

      {addingCatchForSessionId && (
        <CatchModal
          sessionId={addingCatchForSessionId}
          activeSession={sessions.find((s) => s.id === addingCatchForSessionId)}
          onSave={async (catchData) => {
            await onSaveCatch(catchData);
            await onRefreshData();
          }}
          onClose={() => setAddingCatchForSessionId(null)}
        />
      )}

      {editingCatch && (
        <CatchModal
          catchItem={editingCatch}
          sessionId={editingCatch.sessionId}
          activeSession={sessions.find((s) => s.id === editingCatch.sessionId)}
          onSave={async (catchData) => {
            await onSaveCatch(catchData);
            await onRefreshData();
          }}
          onClose={() => setEditingCatch(null)}
        />
      )}
    </div>
  );
};
