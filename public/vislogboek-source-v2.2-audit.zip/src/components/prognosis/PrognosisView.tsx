import React, { useState, useEffect } from 'react';
import {
  FishSpecies,
  ALL_SPECIES,
  DayPrognosis,
  TimeSlot,
  FishingLocation,
  FishingSession,
  TimeSlotAnalysis,
  PresenceObservationType,
} from '../../types';
import { getForecast } from '../../services/weatherService';
import { calculateDayPrognosis, savePrognosisSnapshot } from '../../services/prognosisEngine';
import { SPECIES_PROFILES } from '../../services/fishProfiles';
import {
  Calendar,
  Clock,
  MapPin,
  RefreshCw,
  Sun,
  Moon,
  Sunrise,
  Sunset,
  Wind,
  Gauge,
  Thermometer,
  CloudRain,
  ChevronDown,
  ChevronUp,
  Info,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
  ShieldAlert,
  Sliders,
  Camera,
  BookmarkPlus,
  BookOpen,
  Eye,
  Compass,
  Navigation,
} from 'lucide-react';

interface PrognosisViewProps {
  locations: FishingLocation[];
  sessions: FishingSession[];
  onStartSession: (species?: FishSpecies, locationId?: string) => void;
}

export const PrognosisView: React.FC<PrognosisViewProps> = ({
  locations,
  sessions,
  onStartSession,
}) => {
  const [selectedSpecies, setSelectedSpecies] = useState<FishSpecies | 'Algemeen'>('Karper');
  const [selectedLocationId, setSelectedLocationId] = useState<string>(locations[0]?.id || '');
  const [selectedDurationHours, setSelectedDurationHours] = useState<number>(3);
  const [selectedPresenceObs, setSelectedPresenceObs] =
    useState<PresenceObservationType>('onbekend');
  const [waterTempInput, setWaterTempInput] = useState<string>('');
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [dayPrognoses, setDayPrognoses] = useState<DayPrognosis[]>([]);
  const [weatherUpdatedAt, setWeatherUpdatedAt] = useState<string>('');
  const [isCachedWeather, setIsCachedWeather] = useState<boolean>(false);
  const [expandedSlots, setExpandedSlots] = useState<Record<TimeSlot, boolean>>({
    Ochtend: false,
    Avond: false,
    Middag: false,
    Nacht: false,
  });
  const [showAssumptionsModal, setShowAssumptionsModal] = useState<boolean>(false);
  const [snapshotSavedMsg, setSnapshotSavedMsg] = useState<string | null>(null);
  const [savingSnapshot, setSavingSnapshot] = useState<boolean>(false);

  const selectedLoc = locations.find((l) => l.id === selectedLocationId) || locations[0];

  const fetchAndCalculatePrognoses = async (forceRefresh = false) => {
    setLoading(true);
    try {
      const lat = selectedLoc?.latitude ?? 51.961;
      const lon = selectedLoc?.longitude ?? 5.228;

      const weather = await getForecast(lat, lon, forceRefresh);
      setWeatherUpdatedAt(weather.fetchedAt);
      setIsCachedWeather(weather.isFromCache);

      const parsedWaterTemp =
        waterTempInput.trim() !== '' ? parseFloat(waterTempInput.replace(',', '.')) : null;
      const validWaterTemp = parsedWaterTemp !== null && !isNaN(parsedWaterTemp) ? parsedWaterTemp : null;

      // Genereer de komende 8 dagen (vandaag + 7 dagen)
      const prognosesList: DayPrognosis[] = [];
      const baseDate = new Date();

      for (let i = 0; i < 8; i++) {
        const d = new Date(baseDate);
        d.setDate(baseDate.getDate() + i);
        const dateStr = d.toISOString().slice(0, 10);

        const prog = calculateDayPrognosis(
          dateStr,
          weather.hourly,
          selectedSpecies,
          sessions,
          weather.fetchedAt,
          validWaterTemp,
          baseDate,
          {
            sessionDurationHours: selectedDurationHours,
            locationId: selectedLocationId,
            location: selectedLoc,
            presenceObservation: selectedPresenceObs,
          }
        );
        prognosesList.push(prog);
      }

      setDayPrognoses(prognosesList);
    } catch (e) {
      console.error('Fout bij berekenen visprognose:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAndCalculatePrognoses(false);
  }, [
    selectedSpecies,
    selectedLocationId,
    sessions,
    waterTempInput,
    selectedDurationHours,
    selectedPresenceObs,
  ]);

  const activeDayProg = dayPrognoses[selectedDayIndex] || dayPrognoses[0];

  // Standaard uitsluitend het Aanbevolen Toekomstige Tijdvak uitgeklapt laten zien
  useEffect(() => {
    if (activeDayProg) {
      const best = activeDayProg.bestTimeSlot;
      setExpandedSlots({
        Nacht: best === 'Nacht',
        Ochtend: best === 'Ochtend',
        Middag: best === 'Middag',
        Avond: best === 'Avond',
      });
    }
  }, [activeDayProg?.date, activeDayProg?.bestTimeSlot]);

  const toggleSlot = (slot: TimeSlot) => {
    setExpandedSlots((prev) => ({ ...prev, [slot]: !prev[slot] }));
  };

  const currentProfile =
    selectedSpecies !== 'Algemeen'
      ? SPECIES_PROFILES[selectedSpecies]
      : SPECIES_PROFILES['Overig'];

  const handleSaveSnapshot = async () => {
    if (!activeDayProg) return;
    setSavingSnapshot(true);
    try {
      const snap = await savePrognosisSnapshot(
        activeDayProg,
        selectedDurationHours,
        selectedLocationId,
        selectedLoc?.name,
        undefined,
        activeDayProg.bestTimeSlot !== 'Geen toekomstig tijdvak meer vandaag'
          ? (activeDayProg.bestTimeSlot as TimeSlot)
          : undefined
      );
      setSnapshotSavedMsg(`Momentopname vastgelegd! ID: ${snap.id.slice(0, 16)}... (Modelversie: v2.2)`);
      setTimeout(() => setSnapshotSavedMsg(null), 6000);
    } catch (e) {
      console.error('Fout bij opslaan momentopname:', e);
    } finally {
      setSavingSnapshot(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top Banner / Filters */}
      <div className="rounded-2xl bg-slate-800/90 border border-slate-700/80 p-4 sm:p-5 shadow-lg backdrop-blur">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-700/70">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              Persoonlijke Visprognose
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
              Drie strikt gescheiden uitkomsten: Biologische activiteit, Persoonlijke vangstkans en Beste toekomstige vistijd.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => fetchAndCalculatePrognoses(true)}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-700/80 hover:bg-slate-600 text-xs sm:text-sm font-medium text-slate-200 transition border border-slate-600/60 cursor-pointer disabled:opacity-50"
              title="Haal de nieuwste weersvoorspelling op via Open-Meteo"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Weer vernieuwen
            </button>

            <button
              onClick={() => setShowAssumptionsModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 text-xs sm:text-sm font-medium text-emerald-300 transition border border-emerald-700/50 cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5" />
              Soortprofiel & Bronnen
            </button>
          </div>
        </div>

        {/* Filter Controls Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-4">
          {/* Vissoort selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Gekozen Vissoort *
            </label>
            <select
              value={selectedSpecies}
              onChange={(e) => setSelectedSpecies(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            >
              <option value="Algemeen">Algemeen (geen specifieke doelsoort)</option>
              {ALL_SPECIES.map((sp) => (
                <option key={sp} value={sp}>
                  {sp}
                </option>
              ))}
            </select>
          </div>

          {/* Stek / Locatie */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Visstek / Locatie
            </label>
            <select
              value={selectedLocationId}
              onChange={(e) => setSelectedLocationId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            >
              {locations.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.name} {loc.isBenchmark ? '⭐ (Benchmark)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Gewenste Sessieduur */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Geplande Sessieduur
            </label>
            <select
              value={selectedDurationHours}
              onChange={(e) => setSelectedDurationHours(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            >
              <option value={1}>1 uur (korte sessie)</option>
              <option value={2}>2 uur</option>
              <option value={3}>3 uur (standaard)</option>
              <option value={4}>4 uur</option>
              <option value={6}>6 uur (halve dag)</option>
              <option value={8}>8+ uur (lange sessie)</option>
            </select>
          </div>

          {/* Viswaarneming op de stek */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>Viswaarneming</span>
              <span className="text-[10px] text-cyan-400">Optioneel</span>
            </label>
            <select
              value={selectedPresenceObs}
              onChange={(e) => setSelectedPresenceObs(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            >
              <option value="onbekend">Niet geobserveerd</option>
              <option value="vis_springen_rollen">Vis zien springen / rollen</option>
              <option value="aasbellen_voedselactiviteit">Aasbellen / bodemactiviteit</option>
              <option value="aanbeten">Recente aanbeten / lijnzwemmers</option>
              <option value="recente_vangst_stek">Recente vangst op stek (&lt;48u)</option>
              <option value="geen_waarnemingen">Geen activiteit gezien</option>
            </select>
          </div>

          {/* Handmatige Watertemperatuur (Optioneel) */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span>Watertemp. (°C)</span>
              <span className="text-[10px] text-emerald-400">Gemeten aan stek</span>
            </label>
            <input
              type="text"
              placeholder="bv. 14.5 (leeg = luchttemp.)"
              value={waterTempInput}
              onChange={(e) => setWaterTempInput(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            />
          </div>
        </div>

        {/* Waarschuwing als Algemeen gekozen is */}
        {selectedSpecies === 'Algemeen' && (
          <div className="mt-3 p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/40 flex items-center gap-2 text-xs text-amber-300">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
            <span>
              Er is geen specifieke vissoort geselecteerd. De berekening gebruikt een algemeen gemiddeld profiel zonder soortspecifieke fysiologische responscurve.
            </span>
          </div>
        )}

        {/* Bevestiging opgeslagen momentopname */}
        {snapshotSavedMsg && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-950/70 border border-emerald-600/70 flex items-center gap-2.5 text-xs text-emerald-200 animate-fade-in shadow-md">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <div className="flex-1 font-semibold">{snapshotSavedMsg}</div>
          </div>
        )}
      </div>

      {/* 8-Dagen Strip (Vandaag + komende 7 dagen) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <span className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
            Kies een dag (Vandaag + 7 dagen vooruit)
          </span>
          {weatherUpdatedAt && (
            <span>
              Weer: {new Date(weatherUpdatedAt).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}
              {isCachedWeather ? ' (gecached)' : ' (live Open-Meteo)'}
            </span>
          )}
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
          {dayPrognoses.map((day, idx) => {
            const isSelected = idx === selectedDayIndex;
            const scoreColor =
              day.activityScore >= 7.0
                ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                : day.activityScore >= 4.5
                ? 'text-amber-400 bg-amber-500/10 border-amber-500/30'
                : 'text-rose-400 bg-rose-500/10 border-rose-500/30';

            return (
              <button
                key={day.date}
                onClick={() => setSelectedDayIndex(idx)}
                className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition text-center cursor-pointer ${
                  isSelected
                    ? 'bg-slate-700/90 border-emerald-400 shadow-md ring-2 ring-emerald-500/30'
                    : 'bg-slate-800/70 border-slate-700 hover:bg-slate-700/50'
                }`}
              >
                <span className="text-[11px] font-medium text-slate-400">
                  {idx === 0 ? 'Vandaag' : idx === 1 ? 'Morgen' : day.dayName.split(' ')[0]}
                </span>
                <span className="text-xs font-bold text-slate-200 mt-0.5">
                  {new Date(day.date).getDate()}{' '}
                  {new Intl.DateTimeFormat('nl-NL', { month: 'short' }).format(new Date(day.date))}
                </span>
                <div
                  className={`mt-1.5 px-2 py-0.5 rounded-lg text-xs font-black border ${scoreColor}`}
                >
                  {day.activityScore.toFixed(1)}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 truncate max-w-full">
                  {day.bestTimeSlot === 'Geen toekomstig tijdvak meer vandaag' ? 'Verstreken' : day.bestTimeSlot}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Drie Afzonderlijke Voorspellingen Panel */}
      {activeDayProg && (
        <div className="space-y-6">
          {/* Hoofdsectie: 3 Gescheiden Resultaten (Sectie 2 Blueprint) */}
          <div className="rounded-3xl bg-gradient-to-br from-slate-800 via-slate-850 to-slate-900 border border-slate-700/80 p-5 sm:p-7 shadow-xl space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-700/60">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-500/40">
                    Prognose voor {activeDayProg.dayName}
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-slate-700 text-slate-300 text-xs font-semibold">
                    {activeDayProg.species}
                  </span>
                  <span className="text-xs text-slate-400">
                    Stek: {selectedLoc?.name}
                  </span>
                  <span className="text-xs text-cyan-400 font-medium">
                    Sessieduur: {selectedDurationHours} uur
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-bold text-white mt-1.5">
                  {activeDayProg.summaryRationale}
                </h2>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap self-start lg:self-center">
                <button
                  onClick={handleSaveSnapshot}
                  disabled={savingSnapshot}
                  className="px-4 py-3 rounded-2xl bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-xs sm:text-sm border border-slate-600/80 transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
                  title="Sla deze prognose als onveranderlijke momentopname op vóór je sessie om later empirisch te valideren"
                >
                  <BookmarkPlus className="w-4 h-4 text-cyan-400" />
                  Sla Momentopname Op
                </button>

                <button
                  onClick={() =>
                    onStartSession(
                      selectedSpecies !== 'Algemeen' ? selectedSpecies : undefined,
                      selectedLocationId
                    )
                  }
                  className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-950/50 transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-emerald-200" />
                  Start Sessie op dit moment
                </button>
              </div>
            </div>

            {/* De 3 Gescheiden Voorspellingen Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* VOORSPELLING A: Biologische Activiteitsindex */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-700/70 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
                    <Gauge className="w-4 h-4" />
                    A. Biologische Activiteitsindex
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl sm:text-4xl font-black text-white">
                      {activeDayProg.activityScore.toFixed(1)}
                    </span>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                      / 10
                    </span>
                  </div>
                  <span
                    className={`inline-block mt-2 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      activeDayProg.advice === 'Gunstig'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : activeDayProg.advice === 'Gemiddeld'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {activeDayProg.advice} biologisch perspectief
                  </span>

                  {activeDayProg.presenceInfo && (
                    <div className="mt-2.5 p-2 rounded-xl bg-cyan-950/40 border border-cyan-800/40 text-[11px] text-cyan-200 flex items-start gap-1.5">
                      <Eye className="w-3.5 h-3.5 shrink-0 mt-0.5 text-cyan-400" />
                      <span>{activeDayProg.presenceInfo.note}</span>
                    </div>
                  )}
                </div>

                <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                  <strong>Modelmatige indicatie:</strong> Weerspiegelt fysiologische activiteit volgens het biologische temperatuur- en omgevingsmodel van {activeDayProg.species}. Dit is geen vangstkans of gemeten biologische activiteit.
                </div>
              </div>

              {/* VOORSPELLING B: Geschatte Vangstkans */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-700/70 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
                    <CheckCircle2 className="w-4 h-4" />
                    B. Geschatte Vangstkans (≥1 vis)
                  </div>

                  {activeDayProg.personalCatchChance !== null ? (
                    <div>
                      <div className="text-3xl sm:text-4xl font-black text-cyan-300">
                        {activeDayProg.personalCatchChance}%
                      </div>
                      {activeDayProg.catchUncertaintyInterval && (
                        <div
                          className="text-xs font-semibold text-cyan-400/90 mt-1 cursor-help"
                          title="Binomiaal Wilson-interval van het historische sessiesucces (geen betrouwbaarheidsinterval van de Poisson-duurkans)"
                        >
                          95% Wilson-interval basissessies: [{activeDayProg.catchUncertaintyInterval[0]}% – {activeDayProg.catchUncertaintyInterval[1]}%]
                        </div>
                      )}
                      <div className="text-[11px] text-slate-300 mt-1">
                        Betrouwbaarheid: <strong className="text-white">{activeDayProg.personalCatchConfidence}</strong> ({activeDayProg.relevantSessionCount} vergelijkbare sessies)
                      </div>
                      {activeDayProg.baseRate !== null && activeDayProg.baseRate !== undefined && (
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Historische basisfrequentie doelsoort: {activeDayProg.baseRate}%
                        </div>
                      )}
                      {activeDayProg.expectedCatches !== null && activeDayProg.expectedCatches !== undefined && (
                        <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                          <span className="text-slate-400">Verwachte vangstopbrengst:</span>
                          <span className="font-bold text-cyan-200">
                            ~{activeDayProg.expectedCatches} {activeDayProg.species.toLowerCase()} over {activeDayProg.plannedDurationHours ?? selectedDurationHours}u
                            {activeDayProg.hourlyCatchRate !== null && activeDayProg.hourlyCatchRate !== undefined && (
                              <span className="text-[10px] text-slate-400 font-normal ml-1">
                                (~{activeDayProg.hourlyCatchRate}/u)
                              </span>
                            )}
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>
                      <div className="text-base font-bold text-slate-300">
                        Onvoldoende gegevens
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
                        Er zijn nog onvoldoende vergelijkbare eigen vissessies ({activeDayProg.relevantSessionCount} van minimaal 5 bevestigde sessies) om een verantwoorde vangstkans te berekenen.
                      </p>
                      {activeDayProg.baseRate !== null && activeDayProg.baseRate !== undefined && (
                        <div className="text-[11px] text-slate-300 mt-1">
                          Historische basisfrequentie doelsoort: <strong className="text-white">{activeDayProg.baseRate}%</strong>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                  Kans op minimaal één doelvis bij een geplande duur van {activeDayProg.plannedDurationHours ?? selectedDurationHours} uur (Poisson-model). Vangsttempo blijft constant; cumulatieve kans en verwachte vangstopbrengst stijgen met de duur.
                </div>
              </div>

              {/* VOORSPELLING C: Beste Toekomstige Vistijd */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-700/70 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
                    <Clock className="w-4 h-4" />
                    C. Beste Toekomstige Vistijd
                  </div>

                  {activeDayProg.bestTimeSlot !== 'Geen toekomstig tijdvak meer vandaag' ? (
                    <div>
                      <div className="text-xl sm:text-2xl font-black text-white">
                        {activeDayProg.bestTimeSlot}
                      </div>
                      <div className="text-xs text-amber-300 font-semibold mt-0.5">
                        {activeDayProg.timeSlots[activeDayProg.bestTimeSlot]?.timeRange} (Score: {activeDayProg.timeSlots[activeDayProg.bestTimeSlot]?.activityScore}/10)
                      </div>
                      {activeDayProg.alternativeTimeSlots.length > 0 && (
                        <div className="text-[11px] text-slate-300 mt-1.5">
                          Alternatief: {activeDayProg.alternativeTimeSlots.join(', ')}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>
                      <div className="text-sm font-bold text-slate-300">
                        Geen toekomstig tijdvak meer vandaag
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        Alle tijdvakken voor vandaag zijn verstreken. Vergelijk de tijdvakken van morgen voor de beste toekomstige opties.
                      </p>
                    </div>
                  )}
                </div>

                <div className="pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                  <strong>Toekomstgericht:</strong> Uitsluitend niet-verstreken tijdvakken worden vergeleken. Deze aanbeveling biedt geen absolute vangstgarantie.
                </div>
              </div>
            </div>

            {/* Thermische Waterontwikkeling & Traagheid (Sectie 6-10) */}
            {activeDayProg.thermalAnalysis && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-700/80 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Thermometer className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Thermische Ontwikkeling van het Viswater
                    </span>
                  </div>
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold self-start sm:self-auto ${
                      activeDayProg.thermalAnalysis.trend === 'Waarschijnlijke opwarming'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : activeDayProg.thermalAnalysis.trend === 'Waarschijnlijke afkoeling'
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                        : activeDayProg.thermalAnalysis.trend === 'Ongeveer stabiel'
                        ? 'bg-slate-700 text-slate-300 border border-slate-600'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {activeDayProg.thermalAnalysis.trend} ({activeDayProg.thermalAnalysis.trendConfidence} betrouwbaarheid)
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 block font-semibold">Gemeten Watertemperatuur</span>
                    <span className="text-sm font-bold text-white mt-0.5 block">
                      {activeDayProg.thermalAnalysis.hasMeasuredWaterTemp && activeDayProg.thermalAnalysis.measuredWaterTemp !== null
                        ? `${activeDayProg.thermalAnalysis.measuredWaterTemp} °C (directe meting)`
                        : 'Niet gemeten (leeg gebleven)'}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      {activeDayProg.thermalAnalysis.hasMeasuredWaterTemp
                        ? 'Geverifieerd aan de stek'
                        : 'Nooit kunstmatig als 0 °C opgeslagen'}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 block font-semibold">Modelschatting Watertemperatuur</span>
                    <span className="text-sm font-bold text-cyan-300 mt-0.5 block">
                      {activeDayProg.thermalAnalysis.estimatedWaterTemp !== null
                        ? `~${activeDayProg.thermalAnalysis.estimatedWaterTemp} °C`
                        : 'Onvoldoende data'}
                      {activeDayProg.thermalAnalysis.estimatedRange && (
                        <span className="text-xs font-normal text-slate-400 ml-1.5">
                          [{activeDayProg.thermalAnalysis.estimatedRange[0]} – {activeDayProg.thermalAnalysis.estimatedRange[1]} °C]
                        </span>
                      )}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      Expliciet modelschatting (thermisch evenwicht)
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 block font-semibold">Watermassa & Traagheid</span>
                    <span className="text-sm font-bold text-slate-200 mt-0.5 block">
                      {activeDayProg.thermalAnalysis.inertiaFactor}
                    </span>
                    <span className="text-[10px] text-slate-400 mt-1 block">
                      {activeDayProg.thermalAnalysis.dataPointsAvailable.depthKnown
                        ? `Waterdiepte: ${activeDayProg.thermalAnalysis.dataPointsAvailable.waterDepthMeters} m`
                        : 'Standaarddiepte (2.0 m) aangenomen'}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-xs text-slate-300 space-y-1.5 leading-relaxed">
                  <p>
                    <strong>Verloop & Analyse:</strong> {activeDayProg.thermalAnalysis.summaryRationale}
                  </p>
                  <p className="text-slate-400">
                    <strong>Oppervlaktelaag vs. Bulk:</strong> {activeDayProg.thermalAnalysis.surfaceVsBulkNote}
                  </p>
                  <p className="text-cyan-300/90 pt-1 border-t border-slate-700/40 text-[11px]">
                    <strong>Invloed op de prognose:</strong> {activeDayProg.thermalAnalysis.prognosisImpactNote}
                  </p>
                </div>
              </div>
            )}

            {/* Hengelpositionering & Visbeweging */}
            {activeDayProg.positioningAdvice && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-cyan-800/40 space-y-3.5 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-cyan-950/80 border border-cyan-700/50 text-cyan-400">
                      <Compass className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white uppercase tracking-wider block">
                        Hengelpositionering & Visbeweging
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Tactisch advies op basis van wind, stroming, waterlaag en diepte
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">Betrouwbaarheid advies:</span>
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        activeDayProg.positioningAdvice.confidenceLevel === 'Redelijk'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : activeDayProg.positioningAdvice.confidenceLevel === 'Matig'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {activeDayProg.positioningAdvice.confidenceLevel}
                    </span>
                  </div>
                </div>

                {/* Hoofdadvies en Alternatief */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-800/80 border border-cyan-700/50">
                    <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider block mb-1">
                      Aanbevolen Zoekzone
                    </span>
                    <span className="text-sm font-bold text-white block mb-1.5">
                      {activeDayProg.positioningAdvice.recommendedZone}
                    </span>
                    <p className="text-slate-300 leading-relaxed text-[11px]">
                      {activeDayProg.positioningAdvice.rationale}
                    </p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block mb-1">
                        Tactisch Alternatief
                      </span>
                      <p className="text-slate-300 leading-relaxed text-[11px]">
                        {activeDayProg.positioningAdvice.alternativeOption}
                      </p>
                    </div>
                    <div className="pt-2 mt-2 border-t border-slate-700/50 space-y-1 text-[10px] text-slate-400">
                      <div className="flex items-center justify-between">
                        <span>
                          Wind: {activeDayProg.positioningAdvice.windContext.directionText}{' '}
                          {activeDayProg.positioningAdvice.windContext.speedKmH} km/u
                          {activeDayProg.positioningAdvice.windContext.gustsKmH &&
                            ` (stoten ~${activeDayProg.positioningAdvice.windContext.gustsKmH} km/u)`}
                        </span>
                        <span>Seizoen: {activeDayProg.positioningAdvice.thermalContext.season}</span>
                      </div>
                      {activeDayProg.positioningAdvice.windContext.intraSessionNote && (
                        <p className="text-cyan-300/80 text-[10px]">
                          {activeDayProg.positioningAdvice.windContext.intraSessionNote}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Persoonlijke Leerresultaten (>=11 sessies drempel) */}
                {activeDayProg.positioningAdvice.personalEvidence && (
                  <div className="p-3 rounded-xl bg-slate-850 border border-slate-700/70 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1">
                        <Navigation className="w-3 h-3 text-purple-400" />
                        Persoonlijk Stekprofiel (Richtingshistorie)
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {activeDayProg.positioningAdvice.personalEvidence.totalCompletedSessionsOnSpot} voltooide sessies op stek
                      </span>
                    </div>
                    <p className="text-slate-300 leading-relaxed text-[11px]">
                      {activeDayProg.positioningAdvice.personalEvidence.summaryNote}
                    </p>
                  </div>
                )}

                {/* Expliciete Beperkingen & Ontbrekende Informatie */}
                <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/40 text-[11px] text-slate-400 space-y-1">
                  <span className="font-semibold text-slate-300 block">
                    Belangrijke nuance & ontbrekende gegevens:
                  </span>
                  <ul className="list-disc pl-4 space-y-0.5">
                    {activeDayProg.positioningAdvice.missingInformation.map((info, idx) => (
                      <li key={idx}>{info}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* Databeschikbaarheid & Modelonzekerheden */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/50 space-y-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-purple-400" />
                Databeschikbaarheid & Onzekerheden voor deze dag:
              </span>
              <ul className="text-xs text-slate-300 space-y-1 list-disc pl-5">
                <li>
                  <strong>Watertemperatuur:</strong> {activeDayProg.waterTemperatureInfo?.note}
                </li>
                <li>
                  <strong>Luchtdruktrend:</strong> {activeDayProg.pressureTrendInfo?.note}
                </li>
                <li>
                  <strong>Herkomst prognose:</strong> {activeDayProg.provenance}.
                </li>
                {activeDayProg.uncertaintyNotes &&
                  activeDayProg.uncertaintyNotes.map((un, i) => (
                    <li key={i} className="text-slate-400">
                      {un}
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          {/* Gedetailleerde Analyse per Tijdvak */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-400" />
                Uitklapbare Analyse per Tijdvak
              </h3>
              <span className="text-xs text-slate-400">
                Toont fysiologische temperatuurefficiëntie en niet-lineaire omgevingsfactoren
              </span>
            </div>

            <div className="grid grid-cols-1 gap-3.5">
              {(['Nacht', 'Ochtend', 'Middag', 'Avond'] as TimeSlot[]).map((slot) => {
                const analysis: TimeSlotAnalysis = activeDayProg.timeSlots[slot];
                const isExpanded = expandedSlots[slot];
                const isBest = activeDayProg.bestTimeSlot === slot;
                const isPast = analysis.isPast;

                const slotIcon =
                  slot === 'Nacht' ? (
                    <Moon className="w-4 h-4 text-indigo-400" />
                  ) : slot === 'Ochtend' ? (
                    <Sunrise className="w-4 h-4 text-amber-400" />
                  ) : slot === 'Middag' ? (
                    <Sun className="w-4 h-4 text-yellow-400" />
                  ) : (
                    <Sunset className="w-4 h-4 text-orange-400" />
                  );

                return (
                  <div
                    key={slot}
                    className={`rounded-2xl border transition overflow-hidden ${
                      isPast
                        ? 'bg-slate-900/40 border-slate-800 opacity-60'
                        : isBest
                        ? 'bg-slate-800/90 border-emerald-500/50 shadow-md'
                        : 'bg-slate-800/60 border-slate-700/60'
                    }`}
                  >
                    {/* Header bar */}
                    <button
                      onClick={() => toggleSlot(slot)}
                      className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-700/30 transition cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-slate-900 border border-slate-700">
                          {slotIcon}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-white text-base">{slot}</span>
                            <span className="text-xs text-slate-400 font-medium">
                              ({analysis.timeRange})
                            </span>
                            {isPast ? (
                              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                                Reeds verstreken
                              </span>
                            ) : isBest ? (
                              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                Aanbevolen Toekomstig Tijdvak
                              </span>
                            ) : null}
                          </div>
                          <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                            {analysis.conclusion}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="text-lg font-black text-white">
                            {analysis.activityScore.toFixed(1)}
                            <span className="text-xs text-slate-400 font-normal">/10</span>
                          </div>
                        </div>
                        <div className="p-1 rounded-lg text-slate-400 hover:text-white">
                          {isExpanded ? (
                            <ChevronUp className="w-5 h-5" />
                          ) : (
                            <ChevronDown className="w-5 h-5" />
                          )}
                        </div>
                      </div>
                    </button>

                    {/* Expanded details */}
                    {isExpanded && (
                      <div className="p-4 pt-2 border-t border-slate-700/50 bg-slate-900/40 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          {/* Temperatuur */}
                          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                                <Thermometer className="w-3.5 h-3.5 text-rose-400" />
                                {analysis.temperatureFactor.title}
                              </span>
                              <span
                                className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                  analysis.temperatureFactor.impact === 'positief'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : analysis.temperatureFactor.impact === 'negatief'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-700 text-slate-300'
                                }`}
                              >
                                {analysis.temperatureFactor.impact}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {analysis.temperatureFactor.detail}
                            </p>
                          </div>

                          {/* Luchtdruk */}
                          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                                <Gauge className="w-3.5 h-3.5 text-blue-400" />
                                {analysis.pressureFactor.title}
                              </span>
                              <span
                                className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                  analysis.pressureFactor.impact === 'positief'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : analysis.pressureFactor.impact === 'negatief'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-700 text-slate-300'
                                }`}
                              >
                                {analysis.pressureFactor.impact}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {analysis.pressureFactor.detail}
                            </p>
                          </div>

                          {/* Wind */}
                          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                                <Wind className="w-3.5 h-3.5 text-cyan-400" />
                                {analysis.windFactor.title}
                              </span>
                              <span
                                className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                  analysis.windFactor.impact === 'positief'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : analysis.windFactor.impact === 'negatief'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-700 text-slate-300'
                                }`}
                              >
                                {analysis.windFactor.impact}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {analysis.windFactor.detail}
                            </p>
                          </div>

                          {/* Seizoen */}
                          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                                {analysis.seasonFactor.title}
                              </span>
                              <span
                                className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                  analysis.seasonFactor.impact === 'positief'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : analysis.seasonFactor.impact === 'negatief'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-700 text-slate-300'
                                }`}
                              >
                                {analysis.seasonFactor.impact}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {analysis.seasonFactor.detail}
                            </p>
                          </div>

                          {/* Tijdstip */}
                          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5 text-purple-400" />
                                {analysis.timeOfDayFactor.title}
                              </span>
                              <span
                                className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                  analysis.timeOfDayFactor.impact === 'positief'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : analysis.timeOfDayFactor.impact === 'negatief'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-700 text-slate-300'
                                }`}
                              >
                                {analysis.timeOfDayFactor.impact}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {analysis.timeOfDayFactor.detail}
                            </p>
                          </div>

                          {/* Bewolking / Neerslag */}
                          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/50">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                                <CloudRain className="w-3.5 h-3.5 text-indigo-400" />
                                {analysis.precipitationFactor.title}
                              </span>
                              <span
                                className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                                  analysis.precipitationFactor.impact === 'positief'
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : analysis.precipitationFactor.impact === 'negatief'
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-slate-700 text-slate-300'
                                }`}
                              >
                                {analysis.precipitationFactor.impact}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              {analysis.precipitationFactor.detail}
                            </p>
                          </div>
                        </div>

                        {/* Eigen historische ervaring in dit tijdvak */}
                        <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-xs">
                          <span className="font-bold text-slate-300 block mb-1">
                            Eigen Vangsthistorie in dit tijdvak ({slot}):
                          </span>
                          <span className="text-slate-300">{analysis.personalExperience.note}</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Modal voor Biologische Soortprofielen, Aannames & Wetenschappelijke Bronnen */}
      {showAssumptionsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-emerald-400" />
                  Biologisch Soortprofiel: {currentProfile.dutchName}
                </h3>
                <span className="text-xs text-slate-400 italic">
                  {currentProfile.scientificName}
                </span>
              </div>
              <button
                onClick={() => setShowAssumptionsModal(false)}
                className="rounded-xl p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs sm:text-sm">
              <p className="text-slate-300 leading-relaxed bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700/40">
                {currentProfile.description}
              </p>

              <div>
                <h4 className="font-bold text-white mb-2">Gedocumenteerde Aannames & Fysiologische Eigenschappen:</h4>
                <ul className="space-y-1.5 list-disc pl-5 text-slate-300">
                  {currentProfile.assumptions.map((ass, i) => (
                    <li key={i}>{ass}</li>
                  ))}
                </ul>
              </div>

              {/* Wetenschappelijke Literatuurreferenties */}
              {currentProfile.scientificReferences && currentProfile.scientificReferences.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/40">
                  <h4 className="font-bold text-cyan-300 mb-2 flex items-center gap-1.5">
                    <Info className="w-4 h-4 text-cyan-400" />
                    Controleerbare Wetenschappelijke Bronnen (Ichthyologie):
                  </h4>
                  <ul className="space-y-1 list-disc pl-5 text-slate-300 text-xs">
                    {currentProfile.scientificReferences.map((ref, idx) => (
                      <li key={idx} className="font-mono text-[11px] text-slate-300">{ref}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2">
                <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-700/40">
                  <span className="text-[11px] text-slate-400 block font-semibold">Thermisch Optimum</span>
                  <span className="font-bold text-white">{currentProfile.thermalOptimum} °C</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-700/40">
                  <span className="text-[11px] text-slate-400 block font-semibold">Optimale Zone</span>
                  <span className="font-bold text-white">
                    {currentProfile.optimalTempRange[0]} – {currentProfile.optimalTempRange[1]} °C
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-800/50 border border-slate-700/40">
                  <span className="text-[11px] text-slate-400 block font-semibold">Barometerbereik</span>
                  <span className="font-bold text-white">
                    {currentProfile.optimalPressureRange[0]} – {currentProfile.optimalPressureRange[1]} hPa
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/30 text-xs text-emerald-200">
                <strong>Wetenschappelijke nuance:</strong> Dit model hanteert een continue fysiologische Gaussische respons. Temperatuur fungeert als snelheidsbepalende fysiologische factor (rate-limiting biological constraint): bij temperaturen ver onder het optimum kan een vissoort geen maximale activiteit vertonen, ongeacht gunstige wind of barometerstand.
              </div>
            </div>

            <button
              onClick={() => setShowAssumptionsModal(false)}
              className="mt-6 w-full rounded-2xl bg-slate-800 py-3 text-sm font-bold text-white hover:bg-slate-700 transition cursor-pointer"
            >
              Sluiten
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
